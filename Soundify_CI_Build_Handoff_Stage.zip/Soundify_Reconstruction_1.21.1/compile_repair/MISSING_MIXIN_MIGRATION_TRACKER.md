# Missing Mixin migration tracker

The original Mixin config is retained as historical evidence only. It is not activated in the reconstruction build. Each class below must be reconstructed and mapped to 1.21.1 before activation.

## Audio core priority
- ConfiguredSoundVolumeMixin
- SoundDirectionMixin
- SoundDirectionEngineMixin
- SoundDirectionDelayMixin
- CustomAudioStreamMixin
- ConfiguredSoundPitchMixin
- ConfiguredSoundEnginePitchMixin
- DynamicSoundReplacementMixin
- VanillaSoundReferenceMixin
- CustomSoundReplacementMixin
- AudioLibraryAuxiliarySendsMixin
- SoundifyAudioChannelMixin
- SoundifyAudioEngineMixin
- SoundManagerPreparationsAccessor
- SoundManagerReloadInvoker

## Approach
Use `MIXIN_TARGET_INVENTORY.md` and bytecode dumps to recover original intent. Re-map target classes/methods using Yarn 1.21.1; implement, compile, and test one group at a time. Avoid placeholders/no-op Mixins.
