# Compile/API repair and missing Mixin reconstruction status

## Honest status
This pass performs a source/configuration audit and strengthens the reconstruction package. A full Fabric Loom compile cannot be executed in this environment: Gradle is not installed, and fetching its distribution/dependencies is network-blocked. Therefore, this report does not claim compiler success or Minecraft runtime validation.

## Build blockers and repairs made/identified
- Keep Java toolchain at 21 and target MC 1.21.1/Yarn build.3.
- Use a reduced mixin config containing only source classes that exist; do not register unreconstructed classes. The original 108 mixin set is NOT silently stubbed.
- Resource reload mixin remains an unverified API target: `SoundManager.apply(SoundList, ResourceManager, Profiler)` must be checked against Loom's mapped compile output before runtime.
- Resource adapter parsing is an index-only pass, not proof of physical OGG availability; JSON entries may use `file`, `type`, `stream`, `volume`, `pitch`, `weight`, and event-level subtitle/flags. Current index records only `name` references and must not be used to make runtime playback decisions until completed.
- Catalog/bootstrap code and playback APIs still need mapped compile validation.

## Mixin migration strategy
The original configuration contains 108 Mixin entries. Reconstructing all as no-op classes would falsely represent functionality and can break injection targets. They are divided into migration priority groups based on the target inventory:
1. Core audio: configured volume/pitch, direction, delay, custom stream, dynamic/custom replacement, audio engine/channel, SoundManager accessors.
2. Combat/event detection: player/entity attack, firework, crystal, health-change sounds.
3. Remaining UI/gameplay/other targets: migrate only after target method signatures are confirmed in 1.21.1.

## Compile steps when Gradle is available
1. `./gradlew --version`
2. `./gradlew clean compileJava --stacktrace`
3. Fix compiler errors using Yarn 1.21.1 signatures, not older-version descriptors.
4. `./gradlew runClient` with a clean instance and no unrelated mods.
5. `./gradlew remapJar`

## Validation scope of this pass
- Source tree and build configuration audited.
- Mixin config remains intentionally minimal.
- No full Loom compile or runtime test was available.
