# Dynamic Sound Replacement reconstruction — stage report

## Bytecode-derived control flow
The original `DynamicSoundReplacementMixin` disassembly (batch 04) redirects the queried sound event through `VanillaSoundReplacements.selectedEvent`; if that target resolves, it returns the target event. Otherwise it checks `CustomSoundReplacements.dynamicLookupMayMatch` and `dynamicSoundEvents`, then falls back to `SoundResourcePriority.selectedEvent`. The separate `CustomSoundReplacementMixin` applies custom replacements and vanilla replacement tables during SoundManager resource preparation and updates its sound cache.

## This stage
- Added `sound/replacement/DynamicReplacementResolver.java`: normalized namespaced IDs, multiple configured candidates, primary candidate selection, catalog-aware fallback and config-hash cache invalidation.
- Reuses `ConfigStore.settings().replacementSoundIds`, `replacementSoundId`, and `replacementHash`, and `CustomSounds.contains`.
- Keeps resolver independent of Minecraft mapping-specific `SoundManager` return types so it can be tested in isolation.

## Deliberate limitations
This stage does **not** yet inject into the 1.21.1 SoundManager. The original redirect also includes vanilla resource-priority and custom-dynamic lookup engines; these are not reconstructed here. Actual Fabric/Mixin injection requires verifying the target method and return type against Yarn 1.21.1 and reconciling the catalog/config methods.
