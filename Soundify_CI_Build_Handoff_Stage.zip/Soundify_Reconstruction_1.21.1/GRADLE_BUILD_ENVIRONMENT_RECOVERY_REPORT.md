# Gradle Build Environment Recovery & Compile Error Resolution

Target: Minecraft Java 1.21.1 · Fabric · Yarn `1.21.1+build.3` · Java 21
Build plugin: Fabric Loom `1.10.5` · pinned Gradle distribution `8.12`

## 1. Build configuration repairs

- Moved dependency repositories into `settings.gradle` under `dependencyResolutionManagement`, avoiding the conflict between project-level `repositories {}` and `RepositoriesMode.FAIL_ON_PROJECT_REPOS`.
- Kept plugin resolution repositories in `pluginManagement` (`maven.fabricmc.net` and `gradlePluginPortal`).
- Replaced the deprecated/legacy `archivesBaseName` assignment with `base { archivesName = ... }`.
- Set Java toolchain and compiler release to 21, with UTF-8 source encoding.
- Added Gradle 8.12 distribution metadata in `gradle/wrapper/gradle-wrapper.properties`.
- Added `gradlew` and `gradlew.bat` bootstrap launchers. They bootstrap the pinned Gradle distribution when it is not cached. **These are project bootstrap scripts, not the official Gradle Wrapper JAR.** The official wrapper JAR could not be retrieved in this network-restricted environment.
- Disabled Gradle configuration cache for this reconstruction workspace while plugin behavior is not yet confirmed.

## 2. Java/API repairs applied

- Removed the invalid duplicate `SoundifyConfig.sampleCodePitch(String)` overload and use Yarn's `Random.create()` factory; Yarn 1.21.1 declares `Random` as an interface.
- Replaced the unsupported `PositionedSoundInstance.ui(...)` call with the documented `PositionedSoundInstance.master(SoundEvent, pitch, volume)` factory.
- Replaced the non-existent `CustomSounds.defaultMaxPitch(...)` reference by implementing the matching accessor backed by each catalog entry's maximum pitch.
- Migrated keybinding usage to Yarn 1.21.1 APIs: `InputUtil`, `KeyBinding.setBoundKey`, `KeyBinding.wasPressed`, `KeyBinding.getBoundKeyLocalizedText`, and `KeyBinding.updateKeysByCode`.
- Replaced `MinecraftClient.getInstance().gui.setScreen(...)` with `MinecraftClient.setScreen(...)`.
- Replaced `GameOptions.save()` with the 1.21.1 method `GameOptions.write()`.
- Removed the temporary KeyBinding accessor mixin because `setBoundKey` is public in Yarn 1.21.1.
- Added the reconstructed `ReverbSettings` model, including bounded profile parameters, material settings, presets, and quality levels.
- Marked SoundManager injections as required (`defaultRequire: 1`) after checking target selectors against Yarn 1.21.1+build.3 documentation. The reload hook uses an `@Coerce Object` for the protected nested `SoundManager.SoundList` argument.
- Marked the `SoundManager.sounds` shadow field `@Final` to match the target field declaration.

## 3. API references checked

The following exact Yarn 1.21.1+build.3 API declarations were checked during this stage:

- `net.minecraft.util.math.random.Random` is an interface and offers static `create()`.
- `PositionedSoundInstance.master(SoundEvent, float pitch, float volume)` exists.
- `GameOptions.write()` is public; `GameOptions.save()` is not the mapped 1.21.1 method.
- `KeyBinding` includes the 4-argument constructor, public `setBoundKey`, `wasPressed`, `getBoundKeyLocalizedText`, and `updateKeysByCode`.
- `MinecraftClient.setScreen(Screen)` is public.
- `SoundManager.get(Identifier)` has the mapped descriptor, `sounds` is a private final map, and `apply(SoundManager.SoundList, ResourceManager, Profiler)` is present.
- `SoundManager.SoundList.reload(Map, Map, SoundSystem)` matches the loaded-sound index hook.

## 4. Tests actually run

| Check | Result |
|---|---|
| `sh -n gradlew` | PASS |
| Java 21 runtime present | PASS (`OpenJDK 21.0.12.1`) |
| `ReverbSettings` standalone javac + smoke test | PASS |
| `SoundifyClientScheduler` standalone javac + smoke test | PASS |
| `fabric.mod.json` parse | PASS |
| `soundify-reborn.client.mixins.json` parse | PASS |
| `assets/soundify-reborn/sounds.json` parse | PASS |
| Java source parser scan without external classpath | No Java syntax diagnostics observed; full type-check unavailable |
| Sound asset inventory | 978 audio files retained in project |
| `compileJava` | BLOCKED before Gradle startup |

### Build blocker observed

The command `./gradlew compileJava --stacktrace` was attempted. It exited with code 6 because:

- no system Gradle executable is installed;
- no official `gradle-wrapper.jar` is present;
- the pinned Gradle 8.12 distribution could not be downloaded because DNS resolution for `services.gradle.org` failed (`curl: (6) Could not resolve host`).

The no-classpath `javac` scan reports missing external packages/types (Minecraft, Fabric Loader/API, Mixin, Gson, SLF4J), as expected without Loom's generated compile classpath. It is not a successful compilation and does not prove all Java API typing is correct.

## 5. Not completed / next required verification

- Run `./gradlew clean compileJava` from a machine with internet access (or a populated Gradle cache).
- Resolve any remaining real Loom/compiler diagnostics after dependency resolution.
- Run `./gradlew remapJar` / `./gradlew build`.
- Launch Minecraft 1.21.1 Fabric and confirm all required mixins apply and sound playback/replacement works after resource reload.
- The configuration screen is still a placeholder compatibility screen; the original Soundify settings UI is not reconstructed here.

This archive is a source/build-preparation stage, **not an installable mod JAR**.
