# Resource Adapter Review Stage

## Changes
- Sound definition entries now parse both vanilla string shorthand (`"sounds/foo"`) and object entries (`{"name":"sounds/foo", ...}`).
- Ignore malformed or non-string `name` values safely.
- Sound path references are normalized into a `namespace:sounds/...ogg` logical path without blindly duplicating `sounds/` or `.ogg`.
- A malformed definition remains isolated and does not abort the scan.

## Remaining verification
- No Gradle/Loom compile could be executed in this environment, so Yarn 1.21.1 signatures remain unconfirmed.
- `SoundManager.apply` injection target must be validated in an actual Loom build.
- This index enumerates sound-event definitions and references; it does not confirm that each referenced OGG exists or decode audio.
- Replacement index is still not wired into vanilla playback behavior; a separate verified SoundManager hook is required.
