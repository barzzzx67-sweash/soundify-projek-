# Dynamic Sound Replacement — SoundManager hook reconstruction

## Implemented
- Added `SoundManagerDynamicReplacementMixin` targeting Yarn 1.21.1 `SoundManager.get(Identifier)`.
- At lookup HEAD, the hook uses configured candidate IDs and the published resource-event index to select a distinct replacement.
- It reads the already-loaded `WeightedSoundSet` directly from the SoundManager's `sounds` map and returns it when present; otherwise vanilla lookup proceeds unchanged.
- Registered the hook alongside the existing reload index Mixin.

## Grounding / target
The Yarn 1.21.1+build.3 docs identify `SoundManager.get(Identifier)` as returning `WeightedSoundSet` and the private `sounds` map as `Map<Identifier, WeightedSoundSet>`. This hook follows that documented shape.

## Limitations
- No Gradle/Loom compile or client test was possible in the current environment (Gradle unavailable and Gradle distribution DNS/download blocked in earlier attempts).
- Mixin field shadow and method injection are source-level reconstructed but not compile/runtime verified.
- Replacement is applied only to IDs represented in the indexed sound-definition catalog; it does not replace raw sound-file playback IDs.
- The resource index is currently rebuilt after reload and remains dependent on adapter correctness.
