# Dynamic Replacement — SoundList Registration Integration (Minecraft 1.21.1)

## Implemented

- Added `LoadedSoundSetIndex`, an immutable/atomic snapshot of sound-event IDs actually present in Minecraft's loaded sound-set map.
- Added `SoundListLoadedIndexMixin`, targeting the nested class by its binary target name so source code does not need to reference the protected `SoundManager.SoundList` type.
- The Mixin injects at the tail of `SoundList.reload(Map<Identifier, WeightedSoundSet>, Map<Identifier, Resource>, SoundSystem)` and publishes the keys of the loaded sound-set map.
- Updated `SoundManagerDynamicReplacementMixin` to probe the loaded sound-set snapshot. Candidate resolution now falls through to the next configured candidate if an earlier candidate is not loaded; the existing `sounds.get(target)` check remains as a final guard.
- Changed the reload hook's `SoundList` handler argument to `Object` to avoid directly naming the protected nested type in the source signature.
- Registered the new SoundList Mixin in the client Mixin config.

## Intended reload sequence

1. Vanilla prepares the sound list and applies it.
2. `SoundList.reload` finishes building the loaded sound-set map.
3. `SoundListLoadedIndexMixin` publishes the actual loaded event IDs.
4. `SoundManager.apply` finishes and `SoundManagerResourceReloadMixin` rebuilds the resource-definition index.
5. Sound lookup can redirect only to a candidate present in the loaded sound-set snapshot.

## API evidence

Yarn 1.21.1+build.3 documents `SoundManager.SoundList.loadedSounds` and its `reload(Map<Identifier, WeightedSoundSet>, Map<Identifier, Resource>, SoundSystem)` method, as well as `SoundManager.get(Identifier)`. See the generated Yarn docs:
- https://maven.fabricmc.net/docs/yarn-1.21.1+build.3/net/minecraft/client/sound/SoundManager.SoundList.html
- https://maven.fabricmc.net/docs/yarn-1.21%2Bbuild.1/net/minecraft/client/sound/SoundManager.html

## Validation and limitations

- Static source checks validate the new class, injection target/method, config registration, and replacement probe wiring.
- This is not a Fabric Loom compile or in-game test. The handler signature, Mixin application to the nested class, and runtime ordering still require `compileJava` and client launch validation.
- This stage indexes loaded event sets; it does not rewrite sound JSON, add new sound events, or alter the sound file decoder.
- The current workspace is still a reconstruction project and must not be treated as a finished installable mod.
