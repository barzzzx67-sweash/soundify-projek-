# Sound Playback Runtime Validation (Static Audit)

## Scope
Audit of playback facade, pitch handling, event catalog access, replacement resolver, loaded soundset index, and Mixin hooks in the SoundDefinition Repair stage workspace. This is a static source audit only; no Minecraft runtime or Gradle compile was performed.

## Observations
- `SoundPlayback` routes instance playback and stopping through `SoundManagerBridge`; it constructs positional instances and resolves pitch through `PlaybackPitch`.
- `PlaybackPitch` rejects non-finite and non-positive input/range bounds and delegates mapping/override policy to `SoundifyConfig`.
- `SoundManagerBridge` checks client manager presence and forwards play/stop calls.
- `DynamicReplacementResolver` normalizes candidate IDs, deduplicates configured candidates, and caches by normalized original ID with replacement-hash invalidation.
- `ReplacementResourceResolver.resolveDistinct` filters self-targets and probes candidates, avoiding redirect loops to the original event.
- `LoadedSoundSetIndex` publishes immutable snapshots of loaded IDs and invalidates the replacement resolver on publication.

## Risks / pending validation
1. `SoundPlayback` does not validate volume for finite/non-negative values before constructing instances. Add a policy or verify vanilla behavior.
2. The `directional` boolean in `playLocalConfigured` is retained but currently does not alter instance behavior; the method comment describes future parity only.
3. `SoundManagerDynamicReplacementMixin` shadows a private `sounds` field and injects into `get`; both field and method signatures/visibility must be verified against 1.21.1 Yarn bytecode.
4. `SoundManagerResourceReloadMixin` injects into `apply` using `Object soundList`; the target signature and callback descriptors are not confirmed. A mismatched target can fail injection or silently miss depending on config policy.
5. `SoundListLoadedIndexMixin` targets an inner class by string and injects `reload(Map, Map, SoundSystem, CallbackInfo)`; the exact method descriptor and class name must be verified.
6. Client/server side: these playback methods reference client-only APIs and must only be invoked on client paths.
7. The 22 external `minecraft:` sound references in the repaired definitions remain unverified against the vanilla 1.21.1 asset set.

## Static validation checks
- Source files for playback, replacement, catalog, and mixin hooks present.
- Mixin JSON parses and lists three hooks.
- Fabric metadata parses and declares 1.21.1 / Java 21 dependencies.
- No compile or in-game claims are made.

## Next step
API & Mixin compatibility repair: confirm target descriptors with Loom/Yarn 1.21.1, then compile and test in a client.
