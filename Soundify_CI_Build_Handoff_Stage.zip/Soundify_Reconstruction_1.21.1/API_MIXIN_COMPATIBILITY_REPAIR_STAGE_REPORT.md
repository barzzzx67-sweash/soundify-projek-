# API & Mixin Compatibility Repair — 1.21.1

## Work completed in this pass
- Playback facade now rejects non-finite and negative volume values before creating a sound instance or calling the sound manager.
- Existing pitch validation is retained (finite and strictly positive).
- Reviewed current Mixin source and configuration for the SoundManager dynamic lookup and reload/index hooks.
- Preserved the deliberately minimal Mixin list; no unreconstructed/no-op mixins were added.

## Important remaining verification
- No Gradle executable or wrapper was found in this environment, so `compileJava`/Loom could not be run.
- `SoundManager.apply` and inner `SoundList.reload` injections remain unconfirmed against Yarn 1.21.1 bytecode and should be treated as compile/runtime risks.
- Directional parameter is retained by the facade but this pass does not claim actual directional delay/spatial policy integration.
- The vanilla fallback and replacement hook are statically reviewed only; runtime sound-engine behavior is not established.

## Suggested build verification when Gradle is available
1. `./gradlew clean compileJava --stacktrace`
2. Resolve mapping/signature errors using Yarn 1.21.1.
3. `./gradlew remapJar`
4. Test on a clean Fabric 1.21.1 client with only Fabric API and this mod.
