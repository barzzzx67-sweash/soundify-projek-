# Yarn 1.21.1 Mixin Signature Reconstruction

Scope: static reconstruction against the project target/mapping configuration (Yarn 1.21.1+build.3). This is not a Loom compile or bytecode-confirmed signature report.

## Target review

### SoundManager#get(Identifier)
- Mixin target: `net.minecraft.client.sound.SoundManager`
- Expected Yarn lookup shape: `get(Identifier)` returning `WeightedSoundSet`.
- Injection HEAD, cancellable: plausible and consistent with lookup replacement.
- Shadow `sounds`: likely backing map, but field name/type/visibility are not bytecode-verified.
- Risk: high until Loom compile confirms target and shadow.

### SoundManager#apply(...)
- Mixin target: `SoundManager`
- Injection point: TAIL of `apply`.
- Existing injection handler uses `Object` for first argument, followed by `ResourceManager`, `Profiler`, `CallbackInfo`. Object is a permissive handler parameter, but target argument count/order and descriptor are not verified.
- Risk: medium/high; exact method descriptor must be checked against remapped 1.21.1 bytecode.

### SoundManager$SoundList#reload(...)
- Target class string: `net.minecraft.client.sound.SoundManager$SoundList`.
- Handler types presently: `Map<Identifier, WeightedSoundSet>`, `Map<Identifier, Resource>`, `SoundSystem`, `CallbackInfo`.
- Target argument ordering/types and visibility remain bytecode-unverified.
- Risk: high. Inner-class target and method descriptor must be checked with Loom.

## Source action

No speculative descriptor changes were made: wrong hard-coded descriptors can disable a valid injection or break launch. The three mixins remain provisional and are tracked explicitly. The mixin configuration's `defaultRequire: 0` can hide a missed injection; treat startup as unvalidated until logs prove all hooks applied.

## Separate Yarn mapping blockers discovered

`com.soundify.client.SoundifyClient` still contains Mojang-mapping names (Minecraft, KeyMapping, Screen, Component, Identifier, InputConstants). `ConfigView.java` also imports Mojang `Screen`. These are compile blockers or cross-file mapping incompatibilities in the Yarn build and must be migrated consistently with the GUI/config API. Do not patch these in isolation without examining ConfigScreens and related UI classes.

## Validation status

- Static inspection: performed.
- JSON syntax: previously checked for mixin config.
- Yarn mapping/descriptor verification against Minecraft jar: not performed.
- Fabric Loom compile: not performed.
- Game launch: not performed.

## Next verification commands (once Gradle wrapper and dependencies are available)

1. `./gradlew compileJava`
2. Inspect Loom remapped 1.21.1 client jar for `SoundManager`, `SoundManager$SoundList`, descriptors, and field `sounds`.
3. Verify mixin application in launch log; remove or tighten `defaultRequire: 0` once hooks are confirmed.
4. Run client with resource reload and replacement lookup tests.
