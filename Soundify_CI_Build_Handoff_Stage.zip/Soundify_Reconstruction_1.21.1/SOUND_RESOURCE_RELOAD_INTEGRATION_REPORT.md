# Sound Resource & Reload Integration Stage

## Implemented
- `SoundResourceIndex`: immutable snapshot of sound event IDs and their resolved sound-file references; atomic publication and generation counter.
- `SoundResourceIntegration`: adapter seam to query available replacement event and file references.
- Publication invalidates replacement candidate cache, so candidates are recalculated after a resource reload.

## Adapter contract
A Minecraft 1.21.1 `ResourceManager` adapter still needs to enumerate `sounds.json` definitions and resource layers, resolve each event to the actual file references (including variants/streams), and publish a complete `SoundEntry` collection after successful reload. Publish an empty index only when the adapter intentionally represents an empty resource state. The index itself does not parse Minecraft JSON or claim to be connected to a live game.

## Test coverage
Standalone Java 21 tests exercise atomic publication, normalized lookup, generation increment, replacement selection, and reload cache invalidation using stubbed config/catalog dependencies. Minecraft runtime and Yarn method signatures remain unverified.
