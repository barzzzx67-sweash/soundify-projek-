# SoundManager ResourceManager Adapter & Reload Hook (1.21.1 reconstruction)

## Added
- `MinecraftResourceManagerAdapter`: scans `ResourceManager.findResources("sounds", *.json)`, parses sound definition JSON and builds the resource index.
- `SoundManagerResourceReloadMixin`: injects at the tail of SoundManager `apply(SoundList, ResourceManager, Profiler)` and rebuilds the index after resource reload application.
- Registered the new mixin in the client mixin configuration.

## Scope / caution
This is a mapping-informed reconstruction targeting Yarn 1.21.1 API names. It has not been compiled against a resolved Fabric Loom/Minecraft 1.21.1 dependency set or tested in a live game. Sound file references are indexed from JSON sound entries (the adapter does not validate whether each referenced OGG actually exists). `findResources("sounds", ...)` is intended to discover sound-definition JSON resources in the merged resource manager.

The existing workspace mixin configuration contains numerous unreconstructed mixin names; this package remains a reconstruction workspace and is not yet a safe installable mod.
