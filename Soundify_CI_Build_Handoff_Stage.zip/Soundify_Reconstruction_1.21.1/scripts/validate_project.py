#!/usr/bin/env python3
"""Offline structural validation; does not replace Gradle compilation."""
import json
from pathlib import Path

root = Path(__file__).resolve().parents[1]
required = [
    root / 'src/main/resources/fabric.mod.json',
    root / 'src/main/resources/soundify-reborn.client.mixins.json',
    root / 'src/main/resources/assets/soundify-reborn/sounds.json',
]
for path in required:
    if not path.is_file():
        raise SystemExit(f'MISSING: {path.relative_to(root)}')
    with path.open(encoding='utf-8') as stream:
        json.load(stream)
    print(f'JSON PASS: {path.relative_to(root)}')

meta = json.loads(required[0].read_text(encoding='utf-8'))
for kind, entries in meta.get('entrypoints', {}).items():
    for entry in entries:
        rel = Path('src/main/java') / Path(*entry.split('.')).with_suffix('.java')
        if not (root / rel).is_file():
            raise SystemExit(f'MISSING ENTRYPOINT ({kind}): {rel}')
        print(f'ENTRYPOINT PASS: {entry}')

java_files = list((root / 'src/main/java').rglob('*.java'))
if not java_files:
    raise SystemExit('No Java sources found')
print(f'JAVA SOURCE COUNT: {len(java_files)}')
print('NOTE: This is structural validation only; run Gradle for type checking and remapping.')
