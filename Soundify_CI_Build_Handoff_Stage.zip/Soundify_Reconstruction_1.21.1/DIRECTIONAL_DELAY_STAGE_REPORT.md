# Directional Sound + Delayed Playback — Stage Report

## Recovered from the original 26.3 jar

- `DirectionalSoundInstance` is an interface exposing `soundify$applyDirection()`.
- `SoundDirectionMixin` checks custom sound metadata. A custom sound without directional mode is made camera-relative, centered at (0,0,0), and uses no attenuation. A directional custom sound is converted to world-positioned and uses linear attenuation; if it was camera-relative, the camera position is copied first.
- `SoundDirectionEngineMixin` calls `soundify$applyDirection()` for instances implementing the interface.
- `SoundDirectionDelayMixin` uses distance for a sound when the incoming distance flag is enabled and the event is not marked non-directional.
- `SoundifyClientScheduler` exposes `schedule(int,Runnable)`, `schedule(String,int,Runnable)`, and `onClientTick()`. Keyed scheduling replaces an earlier task with the same key. Tasks are ordered by due tick and sequence.

## Implemented in this stage

- `client/SoundifyClientScheduler.java`: tick-based priority queue, minimum one-tick delay, stable ordering, keyed replacement, cancellation helper, clear/count helpers, and execution outside the queue lock.
- `sound/DirectionalSoundInstance.java`: reconstructed marker contract.
- `sound/DirectionalSoundPolicy.java`: pure policy for directional vs camera-relative placement and attenuation, separated from mapping-specific Minecraft fields.
- `SoundifyClient.java`: registers the scheduler with Fabric `ClientTickEvents.END_CLIENT_TICK`.
- Existing playback stage files are included in this package for continuity.

## Verification

Compiled the scheduler and direction policy using `javac --release 21` and ran a standalone test covering:
- delayed task does not run early and runs on due tick;
- scheduling with same key replaces pending task;
- keyed cancellation prevents execution;
- directional sound uses camera position when transitioning from relative to world-positioned;
- non-directional custom sound becomes centered, relative, and unattenuated.

Result: PASS.

## Not yet verified

This is not a full Minecraft 1.21.1 build. The Mixin injection points and sound instance field access still need to be reconstructed/adapted against the exact 1.21.1 Yarn/Fabric API. The scheduler hook is wired in source, but the complete client entrypoint still references other not-yet-reconstructed classes. No in-game playback test or installable jar is claimed.
