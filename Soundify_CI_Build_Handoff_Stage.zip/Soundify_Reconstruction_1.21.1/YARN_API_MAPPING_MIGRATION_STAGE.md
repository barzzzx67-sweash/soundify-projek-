# Yarn API Mapping Migration Stage — 1.21.1

## Changes made in source
- Migrated client entrypoint imports from Mojang names toward Yarn names: `MinecraftClient`, `KeyBinding`, `InputUtil`, `Text`, and `Identifier`.
- Migrated Fabric key-binding helper to `KeyBindingHelper` / `registerKeyBinding`.
- Changed screen import in `ConfigView` to Yarn `net.minecraft.client.gui.screen.Screen`.
- Changed combat policy entity import from Mojang `LivingEntity` package to Yarn `net.minecraft.entity.LivingEntity`.
- Changed `RandomSource` references in `SoundifyConfig` to Yarn `net.minecraft.util.math.random.Random`.

## Verification and limitations
- These are source-level mapping migrations only; no Gradle/Loom compilation was run.
- KeyBinding.Category construction and update API are particularly version-sensitive and require compile confirmation.
- UI, lifecycle, HUD and config screen implementation classes referenced by this client entrypoint are not present in this reconstructed source tree, so full compile remains blocked by missing project sources in addition to mapping/API uncertainties.
- No in-game test performed.
