# Sound Asset Restoration & Validation — Minecraft 1.21.1

## Restored from original Soundify 1.4.1+26.3 JAR
- Source archive: `soundify-1.4.1+26.3.jar`
- Restored audio files: **978**
- Extensions: `{'.wav': 3, '.ogg': 975}`
- Restored namespace: `assets/soundify-reborn/sounds/`
- OGG/WAV signature failures: **0**

## Generated sounds.json cross-check
- Event definitions: **283**
- Sound references: **743**
- Unique references: **712**
- References found in original JAR: **684**
- Missing references: **59**
- Restored audio files not referenced by generated sounds.json: **322**

## Important findings
The source JAR contains 978 audio assets in the `soundify-reborn` namespace. The generated `sounds.json` has references that do not exactly match all original asset paths. Missing entries are recorded in `SOUND_ASSET_MISSING.csv`; no guessed filename aliases were created. Several references use the `minecraft:` namespace and therefore require the Minecraft 1.21.1 vanilla resource pack to supply them.

The original JAR also contains `assets/minecraft/sounds.json` and `assets/minecraft/sounds/` resources, which are global vanilla overrides. They were **not** copied into the mod's namespace to avoid accidentally changing vanilla sound definitions or duplicating resource-pack overrides.

## Output reports
- `SOUND_ASSET_VALIDATION.csv`: every reference and its resolution status
- `SOUND_ASSET_MISSING.csv`: missing references
- `SOUND_ASSET_UNREFERENCED.csv`: restored assets not referenced by this generated JSON

## Validation limits
This checks archive path existence and basic OGG/WAV file signatures. It does not decode audio, prove that each sound is semantically correct, or establish successful in-game playback. Fabric Loom has not been run.
