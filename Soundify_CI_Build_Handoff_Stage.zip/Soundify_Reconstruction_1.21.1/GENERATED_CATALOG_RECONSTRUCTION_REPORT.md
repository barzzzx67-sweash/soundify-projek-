# Generated Sound Catalog Reconstruction

Source: original `soundify-1.4.1+26.3.jar` class-file static initializers, inspected with `javap` and reconstructed as Java 21-compatible literal tables.

## Recovered data

- `GeneratedSoundCatalog.ENTRIES`: 283 rows, 13 columns each.
- `GeneratedSoundCatalog.SOUNDS`: 283 corresponding sound-variant groups.
- `GeneratedSoundCatalog.NEW_IDS`: 65 IDs.
- `GeneratedSoundCatalog.EDIT_IDS`: 23 IDs.
- `GeneratedVanillaSoundCatalog.ENTRIES`: 112 rows, 13 columns each.
- `GeneratedVanillaSoundCatalog.SOUNDS`: 112 corresponding sound-variant groups.
- `GeneratedVanillaSoundCatalog.ORPHAN_ASSETS`: empty array in the original bytecode.

The generated classes preserve the original public field names and array shapes. Array initializers are split into small helper methods to avoid the JVM 64 KiB method bytecode limit.

## Validation

- Both generated catalog source files compile with `javac --release 21`.
- This validates Java syntax and Java 21 bytecode compatibility only.
- This does not validate integration with Minecraft/Fabric, registration semantics, or runtime sound playback.
- The data tables were reconstructed from bytecode constants; this is not a full decompilation of the original surrounding catalog logic.
