# Fabric 1.21.1 CI build handoff

This stage adds a network-enabled CI build path because the current editing container cannot resolve `services.gradle.org` and has no installed Gradle distribution.

## Local build (machine with internet)

Requirements: JDK 21, Gradle 8.12, internet access to Fabric Maven, Maven Central, Gradle distribution services, and Minecraft libraries.

```sh
python3 scripts/validate_project.py
gradle --version
gradle --no-daemon clean build --stacktrace
```

Expected distributable output, if the build succeeds: `build/libs/*remapped*.jar` or the Loom-produced JAR under `build/libs/`.

## GitHub Actions

The workflow `.github/workflows/fabric-build.yml` runs on push to `main`/`master`, pull requests, or manual dispatch. It provisions Java 21 and Gradle 8.12, runs structural validation and `gradle clean build`, then uploads `build/libs/*.jar` only on success.

The workflow has been authored but **not executed from this environment**. A successful CI run is still required before calling the mod compile-verified. A successful build also does not replace in-game testing of mixin application and sound behavior.
