# Soundify 1.21.1 — Reconstruction workspace

**Not an installable mod and not a successful compile.** This package records actual inspection and partial source reconstruction from the supplied JAR.

## Verified from the user-provided JAR
- 422 `.class` entries overall.
- 385 Soundify-owned classes use class-file major version 69 (Java 25).
- 37 bundled third-party classes use major version 52 (Java 8).
- The original Mixin config lists **108 Mixin entries**. All 108 entries have matching class files.
- The archive contains **111 classes under the Mixin package** because three additional `$1` / nested helper classes accompany listed Mixin classes.
- Original metadata targets Minecraft `~26.3`, Java `>=25`, Fabric Loader `>=0.19.5`.
- Nested libraries include JLayer, MP3SPI, Tritonus Share and LWJGL tinyfd.

## Actual reconstruction completed in this pass
- `SoundifyReborn.java`: exact MOD_ID and logger initialization recovered.
- `SoundifyClient.java`: entrypoint, config keybinding, and config-screen flow reconstructed from the original bytecode. Its references still need mapping/API changes for Minecraft 1.21.1.
- `ConfigStore.java`, `SoundifySettings.java`, `AudioTrimSettings.java`, `PitchSettings.java`, `ReplacementSettings.java`, and `ConfigView.java`: small config facades reconstructed from method bytecode.
- `CombatSoundPolicy.java`: small combat predicate helper reconstructed from all method bodies.
- `bytecode/javap_batch_*.txt`: JVM disassembly for the 385 Soundify-owned classes, grouped into batches.
- `bytecode/mixins_verbose_*.txt`: verbose class/annotation inspection for all 108 declared Mixin classes.
- `MIXIN_TARGET_INVENTORY.md`: original Mixin target classes and injection methods recovered from class annotations where present.
- `MIXIN_MIGRATION_CHECKLIST.md`: per-Mixin porting checklist.

## Known hard blocker
Several lifecycle/scheduler classes contain renamed member identifiers and encoded string-building routines. JDK 21 `javap` can inspect their JVM instructions but does not reconstruct high-level Java source. No Java decompiler binary (Vineflower/CFR) or Minecraft/Fabric 1.21.1 dependency cache is available in this runtime, and direct artifact downloads fail because outbound DNS is unavailable.

## Not done
- The 385 class files are **not all reconstructed into Java source**.
- The 108 Mixin entries have **not** been retargeted to 1.21.1.
- The draft `src/main/resources/fabric.mod.json` and Mixin config are scaffolding only.
- No final JAR has been compiled or tested.

## Next steps
1. Run a real Java decompiler over the 385 application classes.
2. Reconstruct/rename the obfuscated lifecycle code and inspect string decoding.
3. Choose one 1.21.1 mapping namespace and port all 108 Mixin targets, descriptors, and injection points consistently.
4. Resolve Gradle Loom, Minecraft 1.21.1, Fabric Loader/API, MixinExtras, and nested-library dependencies.
5. Compile against Java 21, fix compiler errors, then launch-test each feature group.

## Build recovery notes (Minecraft 1.21.1)

This source workspace targets Java 21, Fabric Loader 0.16.10, Fabric API 0.110.0+1.21.1, Yarn 1.21.1+build.3, Fabric Loom 1.10.5, and Gradle 8.12.

Run `./gradlew clean build` on Linux/macOS or `gradlew.bat clean build` on Windows. The bootstrap launchers download the pinned Gradle distribution on first use if it is not cached. They are project-specific bootstrap scripts, **not** the official Gradle Wrapper JAR. A working internet connection is required to bootstrap Gradle and resolve Loom/Minecraft/Fabric dependencies.

See `GRADLE_BUILD_ENVIRONMENT_RECOVERY_REPORT.md` for the exact checks performed and for the build/runtime steps that remain unverified. This workspace does not yet include an installable JAR.
