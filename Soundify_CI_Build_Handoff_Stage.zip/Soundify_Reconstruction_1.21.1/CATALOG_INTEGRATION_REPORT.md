# Soundify catalog integration — Minecraft 1.21.1 reconstruction

## Changes made

- `CustomSounds.initialize()` now bootstraps both recovered generated catalogs.
- `GeneratedSoundCatalog.ENTRIES` + `SOUNDS` are registered first (283 rows).
- `GeneratedVanillaSoundCatalog.ENTRIES` + `SOUNDS` are attached second (112 rows).
- The combined ID set was checked for duplicates: 395 unique IDs.
- `SoundEventRegistry` now checks the registry with `getOrEmpty`, reuses existing events, and registers missing Soundify events before registry freeze.
- `SoundifyReborn` is now a Fabric `ModInitializer` and invokes the catalog bootstrap during common mod initialization.
- `fabric.mod.json` now declares `com.soundify.SoundifyReborn` as the `main` entrypoint while retaining the client entrypoint.
- Added read-only integration counters and an idempotent initialization guard.

## Validation performed

A Java 21 (`javac --release 21`) compile and smoke test was run against minimal temporary API stubs for the Minecraft/Fabric/SLF4J types used by these five classes. It passed with:

- Custom catalog rows: 283
- Vanilla catalog rows: 112
- Combined catalog IDs: 395
- Parsed sound variants: 1,120
- Soundify SoundEvents registered in the stub registry: 283
- Repeated `CustomSounds.initialize()` call: no duplicate rows
- Lookup checks: `soundify-reborn:advancement` and `minecraft:entity.player.big_fall`

## Important limitations

This is a source-level integration milestone, **not a full Minecraft/Fabric build**. The compile used temporary API stubs, not the real Minecraft 1.21.1 Yarn/Fabric dependencies. It does not prove that the actual 1.21.1 runtime mappings or sound playback behavior are correct. Vanilla SoundEvents are resolved from the runtime registry; custom SoundEvents must be registered before registries freeze, which is why bootstrap is in the main `ModInitializer`.

No final installable mod JAR is produced by this stage.
