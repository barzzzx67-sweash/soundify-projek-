# SoundEventRegistry + Resource Reload Integration (1.21.1)

## Changes

- Added `com.soundify.SoundifyModInitializer` as Fabric's `main` entrypoint. It invokes `CustomSounds.initialize()` during mod initialization, so custom `SoundEvent` registry entries are created before the client sound manager loads sound definitions.
- Added generated `assets/soundify-reborn/sounds.json` from the recovered catalog. It contains definitions for the 283 non-vanilla event IDs and their recovered sound variants (743 variant descriptors). Vanilla override rows are not re-registered as custom IDs.
- Kept the existing `SoundListLoadedIndexMixin`: after vanilla's `SoundList.reload`, it publishes the actual loaded event-set IDs. This means an event is considered available to dynamic replacement only if Minecraft's resource reload produced a loaded `WeightedSoundSet` for it.
- The existing `SoundManagerDynamicReplacementMixin` consults that loaded index and retains vanilla fallback when no replacement set is present.

## Validation performed

- `fabric.mod.json` parses and includes both `main` and `client` entrypoints.
- `sounds.json` parses as JSON.
- Catalog extraction cross-check: 395 catalog rows, 283 custom event definitions, 743 sound variants.
- Every custom catalog ID has a matching top-level key in generated `sounds.json`.
- Every generated definition has a `sounds` array and every variant has a string `name`.

## Important limitations

- This workspace does not contain the actual `.ogg` sound assets. The generated definitions point to recovered logical asset paths, but Minecraft will report missing sound files until those assets are restored/copied into `assets/soundify-reborn/sounds/...ogg`.
- A custom `SoundEvent` being registered does not itself create an audible sound; the matching sound definition and OGG files must also exist.
- The Mixin method signatures and field mappings still require a Fabric Loom compile against Yarn 1.21.1+build.3 and an in-game resource reload test. No compile or runtime success is claimed here.
- The current `SoundifyClient` source still contains references to reconstructed client startup/UI types that are not present in this archive; this pre-existing compile blocker has not been silently treated as fixed.
