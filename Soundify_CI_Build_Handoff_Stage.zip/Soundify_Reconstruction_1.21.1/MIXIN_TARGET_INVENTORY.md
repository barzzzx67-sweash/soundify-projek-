# Mixin annotation and target inventory

Inspected 108 Mixin classes from the original config via `javap -v`. This is original-version bytecode evidence, not a completed 1.21.1 remap.

## `com.soundify.mixin.client.audio.ConfiguredSoundVolumeMixin`
- Original target: `net.minecraft.client.resources.sounds.AbstractSoundInstance`
- Inject: method `getVolume`, At `RETURN`

## `com.soundify.mixin.client.audio.SoundDirectionMixin`
- Original target: `net.minecraft.client.resources.sounds.AbstractSoundInstance`
- No supported injection annotation extracted by this summary parser; inspect verbose dump for accessor/overwrite/other annotations.

## `com.soundify.mixin.client.audio.SoundDirectionEngineMixin`
- Original target: `net.minecraft.client.sounds.SoundEngine`
- Inject: method `play(Lnet/minecraft/client/resources/sounds/SoundInstance;)Lnet/minecraft/client/sounds/SoundEngine$PlayResult;`, At `HEAD`

## `com.soundify.mixin.client.audio.SoundDirectionDelayMixin`
- Original target: `net.minecraft.client.multiplayer.ClientLevel`
- ModifyVariable: method `playSound(DDDLnet/minecraft/sounds/SoundEvent;Lnet/minecraft/sounds/SoundSource;FFZJ)V`, At `HEAD`

## `com.soundify.mixin.client.audio.CustomAudioStreamMixin`
- Original target: `net.minecraft.client.sounds.SoundBufferLibrary`
- Inject: method `getStream`, At `HEAD`

## `com.soundify.mixin.client.audio.ConfiguredSoundPitchMixin`
- Original target: `net.minecraft.client.resources.sounds.AbstractSoundInstance`
- Inject: method `getPitch`, At `RETURN`

## `com.soundify.mixin.client.audio.ConfiguredSoundEnginePitchMixin`
- Original target: `net.minecraft.client.sounds.SoundEngine`
- Inject: method `calculatePitch`, At `RETURN`

## `com.soundify.mixin.client.audio.DynamicSoundReplacementMixin`
- Original target: `net.minecraft.client.sounds.SoundManager`
- Inject: method `getSoundEvent(Lnet/minecraft/resources/Identifier;)Lnet/minecraft/client/sounds/WeighedSoundEvents;`, At `HEAD`

## `com.soundify.mixin.client.audio.VanillaSoundReferenceMixin`
- Original target: `net.minecraft.client.sounds.SoundManager$Preparations$1`
- No supported injection annotation extracted by this summary parser; inspect verbose dump for accessor/overwrite/other annotations.

## `com.soundify.mixin.client.audio.CustomSoundReplacementMixin`
- Original target: `net.minecraft.client.sounds.SoundManager`
- Inject: method `apply(Ljava/lang/Object;Lnet/minecraft/server/packs/resources/ResourceManager;Lnet/minecraft/util/profiling/ProfilerFiller;)V`, At `HEAD`
- Inject: method `prepare(Lnet/minecraft/server/packs/resources/ResourceManager;Lnet/minecraft/util/profiling/ProfilerFiller;)Lnet/minecraft/client/sounds/SoundManager$Preparations;`, At `RETURN`

## `com.soundify.mixin.client.audio.AudioLibraryAuxiliarySendsMixin`
- Original target: `com.mojang.blaze3d.audio.Library`
- ModifyArgs: method `init`, At `INVOKE`

## `com.soundify.mixin.client.audio.SoundifyAudioChannelMixin`
- Original target: `com.mojang.blaze3d.audio.Channel`
- Inject: method `destroy`, At `HEAD`
- Inject: method `setPitch`, At `TAIL`
- Inject: method `stop`, At `HEAD`
- Inject: method `disableAttenuation`, At `TAIL`
- Inject: method `linearAttenuation`, At `TAIL`
- Inject: method `play`, At `HEAD`

## `com.soundify.mixin.client.audio.SoundifyAudioEngineMixin`
- Original target: `net.minecraft.client.sounds.SoundEngine`
- Inject: method `play(Lnet/minecraft/client/resources/sounds/SoundInstance;)Lnet/minecraft/client/sounds/SoundEngine$PlayResult;`, At `RETURN`
- Inject: method `tick`, At `TAIL`
- Inject: method `reload,destroy`, At `HEAD`
- Inject: method `tick`, At `RETURN`
- Inject: method `tick`, At `HEAD`

## `com.soundify.mixin.client.audio.SoundManagerPreparationsAccessor`
- Original target: `net.minecraft.client.sounds.SoundManager$Preparations`
- No supported injection annotation extracted by this summary parser; inspect verbose dump for accessor/overwrite/other annotations.

## `com.soundify.mixin.client.audio.SoundManagerReloadInvoker`
- Original target: `net.minecraft.client.sounds.SoundManager`
- No supported injection annotation extracted by this summary parser; inspect verbose dump for accessor/overwrite/other annotations.

## `com.soundify.mixin.client.combat.PlayerSwingSoundMixin`
- Original target: `net.minecraft.client.Minecraft`
- Inject: method `startAttack`, At `INVOKE`
- Inject: method `startAttack`, At `INVOKE`

## `com.soundify.mixin.client.combat.EntityAttackSoundDetectorMixin`
- Original target: `net.minecraft.world.entity.Entity`
- Inject: method `playSound(Lnet/minecraft/sounds/SoundEvent;FF)V`, At `HEAD`

## `com.soundify.mixin.client.combat.FireworkBlastSoundReplacementMixin`
- Original target: `net.minecraft.client.particle.FireworkParticles$Starter`
- Redirect: method `tick`, At `INVOKE`

## `com.soundify.mixin.client.combat.FireworkRocketExplosionMarkerMixin`
- Original target: `net.minecraft.world.entity.projectile.FireworkRocketEntity`
- Inject: method `handleEntityEvent`, At `HEAD`

## `com.soundify.mixin.client.combat.EndCrystalHitSoundMixin`
- Original target: `net.minecraft.world.entity.player.Player`
- Inject: method `attackVisualEffects`, At `HEAD`

## `com.soundify.mixin.client.combat.LivingEntityHealthChangeMixin`
- Original target: `net.minecraft.world.entity.LivingEntity`
- Inject: method `setHealth`, At `HEAD`
- Inject: method `setAbsorptionAmount`, At `HEAD`

## `com.soundify.mixin.client.combat.EntityExplosionDeathSoundMixin`
- Original target: `net.minecraft.world.entity.LivingEntity`
- Inject: method `handleEntityEvent`, At `HEAD`

## `com.soundify.mixin.client.combat.LocalArrowEntityHitSoundMixin`
- Original target: `net.minecraft.world.entity.projectile.arrow.AbstractArrow`
- Redirect: method `onHitEntity`, At `INVOKE`
- Inject: method `onHitEntity`, At `HEAD`

## `com.soundify.mixin.client.combat.LocalTridentEntityHitMixin`
- Original target: `net.minecraft.world.entity.projectile.arrow.ThrownTrident`
- Inject: method `onHitEntity`, At `HEAD`

## `com.soundify.mixin.client.combat.LungeAttackSoundMixin`
- Original target: `net.minecraft.client.multiplayer.MultiPlayerGameMode`
- Inject: method `useItem`, At `HEAD`
- Inject: method `piercingAttack`, At `HEAD`

## `com.soundify.mixin.client.combat.MaceSmashSoundMixin`
- Original target: `net.minecraft.client.multiplayer.ClientLevel`
- Inject: method `playSound(DDDLnet/minecraft/sounds/SoundEvent;Lnet/minecraft/sounds/SoundSource;FFZJ)V`, At `HEAD`

## `com.soundify.mixin.client.combat.MaceWindupSoundMixin`
- Original target: `net.minecraft.client.player.LocalPlayer`
- Inject: method `tick`, At `HEAD`

## `com.soundify.mixin.client.combat.MaceWindBurstSoundMixin`
- Original target: `net.minecraft.client.multiplayer.ClientPacketListener`
- Inject: method `handleExplosion`, At `TAIL`

## `com.soundify.mixin.client.combat.PlayerAttackSoundMixin`
- Original target: `net.minecraft.client.multiplayer.MultiPlayerGameMode`
- Inject: method `attack`, At `HEAD`

## `com.soundify.mixin.client.combat.ProjectileDamagePacketMixin`
- Original target: `net.minecraft.client.multiplayer.ClientPacketListener`
- Inject: method `handleDamageEvent`, At `INVOKE`

## `com.soundify.mixin.client.combat.ProjectileDeflectSoundMixin`
- Original target: `net.minecraft.world.entity.player.Player`
- Inject: method `attack`, At `HEAD`

## `com.soundify.mixin.client.item.ShieldRaiseSoundMixin`
- Original target: `net.minecraft.world.entity.LivingEntity`
- Inject: method `startUsingItem`, At `HEAD`

## `com.soundify.mixin.client.item.ShieldReadySoundMixin`
- Original target: `net.minecraft.world.item.ItemCooldowns`
- Inject: method `onCooldownEnded`, At `TAIL`
- Inject: method `onCooldownStarted`, At `TAIL`

## `com.soundify.mixin.client.combat.SweepAttackSoundMixin`
- Original target: `net.minecraft.client.particle.AttackSweepParticle`
- Inject: method `<init>`, At `RETURN`

## `com.soundify.mixin.client.effects.LowHealthHeartbeatSoundMixin`
- Original target: `net.minecraft.client.player.LocalPlayer`
- Inject: method `tick`, At `HEAD`
- Inject: method `hurtTo`, At `TAIL`

## `com.soundify.mixin.client.movement.JumpBoostLandingSoundMixin`
- Original target: `net.minecraft.world.entity.LivingEntity`
- Inject: method `jumpFromGround`, At `HEAD`

## `com.soundify.mixin.client.movement.EntityBlockFallSoundMixin`
- Original target: `net.minecraft.world.entity.LivingEntity`
- Inject: method `playBlockFallSound`, At `HEAD`

## `com.soundify.mixin.client.effects.PotionEffectApplySoundMixin`
- Original target: `net.minecraft.world.entity.LivingEntity`
- Inject: method `onEffectsRemoved`, At `HEAD`
- Inject: method `onEffectAdded`, At `HEAD`
- Inject: method `removeEffectNoUpdate`, At `RETURN`
- Inject: method `onEffectUpdated`, At `HEAD`

## `com.soundify.mixin.client.movement.ArmorStepSoundMixin`
- Original target: `net.minecraft.world.entity.Entity`
- Inject: method `playStepSound`, At `TAIL`
- Inject: method `playCombinationStepSounds`, At `TAIL`

## `com.soundify.mixin.client.movement.EntityBlockStepSoundMixin`
- Original target: `net.minecraft.world.entity.Entity`
- ModifyArg: method `playStepSound,playCombinationStepSounds,playMuffledStepSound`, At `INVOKE`

## `com.soundify.mixin.client.gui.AdvancementToastSoundMixin`
- Original target: `net.minecraft.client.gui.components.toasts.AdvancementToast`
- Inject: method `getSoundEvent`, At `RETURN`

## `com.soundify.mixin.client.gui.WidgetHoverSoundMixin`
- Original target: `net.minecraft.client.gui.components.AbstractWidget`
- Inject: method `extractRenderState`, At `HEAD`

## `com.soundify.mixin.client.gui.EnchantmentRejectSoundMixin`
- Original target: `net.minecraft.client.gui.screens.inventory.EnchantmentScreen`
- Inject: method `extractBackground`, At `RETURN`
- Inject: method `mouseClicked`, At `HEAD`

## `com.soundify.mixin.client.gui.MerchantRejectSoundMixin`
- Original target: `net.minecraft.client.gui.screens.inventory.MerchantScreen`
- Inject: method `postButtonClick`, At `INVOKE`

## `com.soundify.mixin.client.gui.RecipeBookCraftDeniedSoundMixin`
- Original target: `net.minecraft.client.gui.screens.recipebook.RecipeBookComponent`
- Inject: method `tryPlaceRecipe`, At `HEAD`

## `com.soundify.mixin.client.gui.RecipeBookTabClickSoundMixin`
- Original target: `net.minecraft.client.gui.components.AbstractWidget`
- Inject: method `playDownSound`, At `HEAD`

## `com.soundify.mixin.client.item.CompassMenuSoundMixin`
- Original target: `net.minecraft.client.gui.Gui`
- Inject: method `setScreen`, At `TAIL`

## `com.soundify.mixin.client.gui.CreativeSlotClickSoundMixin`
- Original target: `net.minecraft.client.gui.screens.inventory.CreativeModeInventoryScreen`
- Inject: method `slotClicked(Lnet/minecraft/world/inventory/Slot;IILnet/minecraft/world/inventory/ContainerInput;)V`, At `HEAD`
- Inject: method `slotClicked(Lnet/minecraft/world/inventory/Slot;IILnet/minecraft/world/inventory/ContainerInput;)V`, At `RETURN`

## `com.soundify.mixin.client.gui.CreativeTabClickSoundMixin`
- Original target: `net.minecraft.client.gui.screens.inventory.CreativeModeInventoryScreen`
- Inject: method `selectTab`, At `HEAD`

## `com.soundify.mixin.client.gui.CreativeTabMouseReleaseSoundMixin`
- Original target: `net.minecraft.client.MouseHandler`
- Inject: method `onButton`, At `RETURN`
- Inject: method `onButton`, At `HEAD`

## `com.soundify.mixin.client.gui.DeathScreenOpenSoundMixin`
- Original target: `net.minecraft.client.gui.Gui`
- Inject: method `setScreen`, At `HEAD`

## `com.soundify.mixin.client.gui.DeathScreenRespawnSoundMixin`
- Original target: `net.minecraft.client.player.LocalPlayer`
- Inject: method `respawn`, At `HEAD`

## `com.soundify.mixin.client.gui.TabListOpenSoundMixin`
- Original target: `net.minecraft.client.gui.components.PlayerTabOverlay`
- Inject: method `extractRenderState`, At `HEAD`
- Inject: method `setVisible`, At `HEAD`

## `com.soundify.mixin.client.gui.ScreenOpenCloseSoundMixin`
- Original target: `net.minecraft.client.gui.Gui`
- Inject: method `setScreen`, At `HEAD`

## `com.soundify.mixin.client.gui.ScreenKeyboardSoundMixin`
- Original target: `net.minecraft.client.gui.screens.Screen`
- Inject: method `keyPressed`, At `HEAD`

## `com.soundify.mixin.client.gui.KeyboardDeleteKeyReleaseMixin`
- Original target: `net.minecraft.client.KeyboardHandler`
- Inject: method `keyPress`, At `HEAD`

## `com.soundify.mixin.client.gui.TextFieldTypingSoundMixin`
- Original target: `net.minecraft.client.gui.components.EditBox`
- Inject: method `insertText`, At `RETURN`
- Inject: method `deleteCharsToPos`, At `RETURN`
- Inject: method `insertText`, At `HEAD`
- Inject: method `deleteCharsToPos`, At `HEAD`

## `com.soundify.mixin.client.gui.TitleMessageSoundMixin`
- Original target: `net.minecraft.client.gui.Hud`
- Inject: method `setTitle`, At `HEAD`

## `com.soundify.mixin.client.gui.TitleScreenMixin`
- Original target: `net.minecraft.client.gui.screens.TitleScreen`
- Inject: method `init`, At `TAIL`
- Inject: method `init`, At `MIXINEXTRAS:EXPRESSION`

## `com.soundify.mixin.client.gui.SoundifyGuiScaleMixin`
- Original target: `net.minecraft.client.Minecraft`
- ModifyArg: method `resizeGui`, At `INVOKE`

## `com.soundify.mixin.client.gui.SoundifyScreenScaleMixin`
- Original target: `net.minecraft.client.gui.Gui`
- Inject: method `setScreen`, At `TAIL`

## `com.soundify.mixin.client.inventory.PlayerDropSoundMixin`
- Original target: `net.minecraft.client.multiplayer.MultiPlayerGameMode`
- Inject: method `dropItem`, At `HEAD`

## `com.soundify.mixin.client.inventory.AnvilRejectSoundMixin`
- Original target: `net.minecraft.client.gui.screens.inventory.AbstractContainerScreen`
- Inject: method `slotClicked(Lnet/minecraft/world/inventory/Slot;ILnet/minecraft/client/input/MouseButtonEvent;Lnet/minecraft/world/inventory/ContainerInput;)V`, At `HEAD`

## `com.soundify.mixin.client.inventory.ContainerRejectStateMixin`
- Original target: `net.minecraft.world.inventory.AbstractContainerMenu`
- Inject: method `setData`, At `RETURN`
- Inject: method `setItem`, At `RETURN`

## `com.soundify.mixin.client.inventory.CraftingResultPickupSoundMixin`
- Original target: `net.minecraft.client.multiplayer.MultiPlayerGameMode`
- Inject: method `handleContainerInput(IIILnet/minecraft/world/inventory/ContainerInput;Lnet/minecraft/world/entity/player/Player;)V`, At `HEAD`
- Inject: method `handleContainerInput(IIILnet/minecraft/world/inventory/ContainerInput;Lnet/minecraft/world/entity/player/Player;)V`, At `RETURN`

## `com.soundify.mixin.client.inventory.HotbarSelectionSoundMixin`
- Original target: `net.minecraft.world.entity.player.Inventory`
- Inject: method `setSelectedSlot(I)V`, At `HEAD`
- Inject: method `setSelectedSlot(I)V`, At `TAIL`
- Inject: method `setItem`, At `HEAD`

## `com.soundify.mixin.client.inventory.InventorySlotClickSoundMixin`
- Original target: `net.minecraft.client.multiplayer.MultiPlayerGameMode`
- Inject: method `handleContainerInput(IIILnet/minecraft/world/inventory/ContainerInput;Lnet/minecraft/world/entity/player/Player;)V`, At `HEAD`
- Inject: method `handleContainerInput(IIILnet/minecraft/world/inventory/ContainerInput;Lnet/minecraft/world/entity/player/Player;)V`, At `RETURN`

## `com.soundify.mixin.client.inventory.ContainerDragSoundMixin`
- Original target: `net.minecraft.client.gui.screens.inventory.AbstractContainerScreen`
- Inject: method `mouseDragged(Lnet/minecraft/client/input/MouseButtonEvent;DD)Z`, At `INVOKE`
- Inject: method `removed`, At `HEAD`
- Inject: method `mouseClicked(Lnet/minecraft/client/input/MouseButtonEvent;Z)Z`, At `HEAD`
- Inject: method `mouseReleased(Lnet/minecraft/client/input/MouseButtonEvent;)Z`, At `RETURN`

## `com.soundify.mixin.client.inventory.ContainerQuickMoveSoundMixin`
- Original target: `net.minecraft.client.gui.screens.inventory.AbstractContainerScreen`
- Inject: method `removed`, At `HEAD`
- Inject: method `mouseClicked(Lnet/minecraft/client/input/MouseButtonEvent;Z)Z`, At `HEAD`
- Inject: method `mouseReleased(Lnet/minecraft/client/input/MouseButtonEvent;)Z`, At `RETURN`

## `com.soundify.mixin.client.item.BowReleaseSoundMixin`
- Original target: `net.minecraft.world.item.BowItem`
- Redirect: method `releaseUsing`, At `INVOKE`
- Inject: method `releaseUsing`, At `RETURN`

## `com.soundify.mixin.client.item.BowPullSoundMixin`
- Original target: `net.minecraft.world.item.BowItem`
- Inject: method `use`, At `INVOKE`

## `com.soundify.mixin.client.item.CompactTowerSoundMixin`
- Original target: `net.minecraft.client.multiplayer.MultiPlayerGameMode`
- Inject: method `useItemOn`, At `RETURN`
- Inject: method `useItemOn`, At `HEAD`

## `com.soundify.mixin.client.item.ElytraFlightStateMixin`
- Original target: `net.minecraft.client.player.LocalPlayer`
- Inject: method `onSyncedDataUpdated`, At `INVOKE`

## `com.soundify.mixin.client.item.PiercingCrossbowSoundMixin`
- Original target: `net.minecraft.world.item.CrossbowItem`
- Inject: method `use`, At `INVOKE`
- Inject: method `performShooting`, At `HEAD`

## `com.soundify.mixin.client.item.QuickChargeCrossbowSoundMixin`
- Original target: `net.minecraft.world.item.CrossbowItem`
- Inject: method `use`, At `INVOKE`

## `com.soundify.mixin.client.item.DrinkUseSoundMixin`
- Original target: `net.minecraft.world.item.Item`
- Inject: method `use`, At `RETURN`
- Inject: method `finishUsingItem`, At `HEAD`

## `com.soundify.mixin.client.item.PotionThrowSoundMixin`
- Original target: `net.minecraft.world.item.SplashPotionItem`
- Inject: method `use`, At `HEAD`
- Redirect: method `use`, At `INVOKE`

## `com.soundify.mixin.client.item.ProjectileThrowSoundMixin`
- Original target: `net.minecraft.world.item.EggItem`
- Redirect: method `use`, At `INVOKE`
- Inject: method `use`, At `HEAD`

## `com.soundify.mixin.client.item.EndCrystalPlaceSoundMixin`
- Original target: `net.minecraft.world.item.EndCrystalItem`
- Inject: method `useOn`, At `RETURN`

## `com.soundify.mixin.client.item.EggImpactSoundMixin`
- Original target: `net.minecraft.world.entity.projectile.throwableitemprojectile.ThrownEgg`
- Inject: method `handleEntityEvent`, At `HEAD`

## `com.soundify.mixin.client.item.EnderPearlImpactSoundMixin`
- Original target: `net.minecraft.world.entity.projectile.throwableitemprojectile.ThrownEnderpearl`
- Inject: method `onHit`, At `HEAD`

## `com.soundify.mixin.client.item.FireworkCrossbowReadySoundMixin`
- Original target: `net.minecraft.world.item.CrossbowItem`
- Inject: method `use`, At `INVOKE`
- Inject: method `performShooting`, At `HEAD`

## `com.soundify.mixin.client.item.FireworkRocketUseSoundMixin`
- Original target: `net.minecraft.world.item.FireworkRocketItem`
- Inject: method `use`, At `RETURN`
- Inject: method `useOn`, At `RETURN`

## `com.soundify.mixin.client.item.SnowballImpactSoundMixin`
- Original target: `net.minecraft.world.entity.projectile.throwableitemprojectile.Snowball`
- Inject: method `handleEntityEvent`, At `HEAD`

## `com.soundify.mixin.client.item.SpearUseEndSoundMixin`
- Original target: `net.minecraft.world.entity.LivingEntity`
- Inject: method `tick`, At `TAIL`

## `com.soundify.mixin.client.item.TridentThrowSoundMixin`
- Original target: `net.minecraft.world.item.TridentItem`
- Inject: method `releaseUsing`, At `INVOKE`

## `com.soundify.mixin.client.item.TridentChargeSoundMixin`
- Original target: `net.minecraft.world.item.TridentItem`
- Inject: method `use`, At `INVOKE`

## `com.soundify.mixin.client.item.TridentRiptideSoundMixin`
- Original target: `net.minecraft.world.item.TridentItem`
- Inject: method `releaseUsing`, At `INVOKE`

## `com.soundify.mixin.client.item.FishingHookEntitySoundMixin`
- Original target: `net.minecraft.world.entity.projectile.FishingHook`
- Inject: method `onSyncedDataUpdated`, At `RETURN`
- Inject: method `handleEntityEvent`, At `HEAD`
- Inject: method `onSyncedDataUpdated`, At `RETURN`

## `com.soundify.mixin.client.item.FishingRodReelSoundMixin`
- Original target: `net.minecraft.world.item.FishingRodItem`
- Inject: method `use`, At `HEAD`

## `com.soundify.mixin.client.item.WindChargeThrowSoundMixin`
- Original target: `net.minecraft.world.item.WindChargeItem`
- Inject: method `use`, At `HEAD`
- Redirect: method `use`, At `INVOKE`

## `com.soundify.mixin.client.network.TridentReturnSoundMixin`
- Original target: `net.minecraft.client.multiplayer.ClientPacketListener`
- Inject: method `handleTakeItemEntity`, At `INVOKE`

## `com.soundify.mixin.client.network.FishingCatchSoundMixin`
- Original target: `net.minecraft.client.multiplayer.ClientPacketListener`
- Inject: method `handleAddEntity`, At `TAIL`

## `com.soundify.mixin.client.network.RemoteSoundReplacementMixin`
- Original target: `net.minecraft.client.multiplayer.ClientPacketListener`
- Redirect: method `handleLevelEvent`, At `INVOKE`
- Inject: method `handleGameEvent`, At `INVOKE`
- Inject: method `handleSoundEvent`, At `INVOKE`

## `com.soundify.mixin.client.network.EntityDeathPacketMixin`
- Original target: `net.minecraft.client.multiplayer.ClientPacketListener`
- Inject: method `handleEntityEvent`, At `INVOKE`

## `com.soundify.mixin.client.network.ExplosionSoundReplacementMixin`
- Original target: `net.minecraft.client.multiplayer.ClientPacketListener`
- Redirect: method `handleExplosion`, At `INVOKE`
- Inject: method `handleExplosion`, At `HEAD`

## `com.soundify.mixin.client.network.FireballSpawnSoundMixin`
- Original target: `net.minecraft.client.multiplayer.ClientPacketListener`
- Inject: method `handleAddEntity`, At `TAIL`

## `com.soundify.mixin.client.network.ProjectileRemoveImpactSoundMixin`
- Original target: `net.minecraft.client.multiplayer.ClientPacketListener`
- Inject: method `handleRemoveEntities`, At `INVOKE`

## `com.soundify.mixin.client.server.ServerJoinSoundMixin`
- Original target: `net.minecraft.client.multiplayer.ClientPacketListener`
- Inject: method `handleLogin`, At `TAIL`

## `com.soundify.mixin.client.server.BedwarsBedBreakSoundMixin`
- Original target: `net.minecraft.client.multiplayer.ClientLevel`
- Inject: method `sendBlockUpdated`, At `HEAD`

## `com.soundify.mixin.client.server.BedwarsTntTimerSoundMixin`
- Original target: `net.minecraft.client.multiplayer.ClientLevel`
- Inject: method `addEntity`, At `RETURN`

## `com.soundify.mixin.client.world.BlockSoundTypeMixin`
- Original target: `net.minecraft.world.level.block.state.BlockBehaviour$BlockStateBase`
- Inject: method `getSoundType`, At `HEAD`

## `com.soundify.mixin.client.world.EntityHitSoundReplacementMixin`
- Original target: `net.minecraft.client.multiplayer.ClientLevel`
- Inject: method `playSeededSound(Lnet/minecraft/world/entity/Entity;DDDLnet/minecraft/core/Holder;Lnet/minecraft/sounds/SoundSource;FFJ)V`, At `HEAD`
- Inject: method `playSeededSound(Lnet/minecraft/world/entity/Entity;Lnet/minecraft/world/entity/Entity;Lnet/minecraft/core/Holder;Lnet/minecraft/sounds/SoundSource;FFJ)V`, At `HEAD`

## `com.soundify.mixin.client.world.ExperienceLevelUpSoundMixin`
- Original target: `net.minecraft.client.player.LocalPlayer`
- Inject: method `setExperienceValues`, At `TAIL`

## `com.soundify.mixin.client.world.MetalBlockBreakSoundMixin`
- Original target: `net.minecraft.client.renderer.LevelEventHandler`
- Redirect: method `levelEvent`, At `INVOKE`

## `com.soundify.mixin.client.world.RespawnAnchorUseSoundMarkerMixin`
- Original target: `net.minecraft.world.level.block.RespawnAnchorBlock`
- Inject: method `useWithoutItem`, At `HEAD`

## `com.soundify.mixin.client.movement.SneakToggleSoundMixin`
- Original target: `net.minecraft.client.KeyMapping`
- Inject: method `setDown`, At `HEAD`

## `com.soundify.mixin.client.movement.WaterSwimPoseMixin`
- Original target: `net.minecraft.world.entity.Entity`
- Inject: method `setPose`, At `TAIL`
- Inject: method `setPose`, At `HEAD`
