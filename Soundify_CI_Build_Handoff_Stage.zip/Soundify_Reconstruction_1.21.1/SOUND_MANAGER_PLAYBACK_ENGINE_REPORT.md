# SoundManager + SoundPlayback reconstruction stage

## Source changes

Added Java 21 source files under `src/main/java/com/soundify/sound/`:

- `SoundManagerBridge.java`: client-side bridge for `MinecraftClient.getSoundManager()`, play, and stop.
- `SoundPlayback.java`: UI, player/entity, and world-positioned playback facade, configured pitch resolution, and catalog lookup.
- `PlaybackPitch.java`: runtime pitch and mapped-range policy; delegates configured overrides to `SoundifyConfig`.
- `SoundPitch.java`: random pitch range helper, including the built-in randomized code-pitch catalog.

## Behavior implemented

- UI playback through `PositionedSoundInstance.ui`.
- Positional playback through `PositionedSoundInstance`.
- Entity/player playback using current entity coordinates.
- Catalog lookup through `CustomSounds`.
- Category mapping from catalog labels to Yarn `SoundCategory` values.
- Runtime pitch overrides and mapped code-pitch overrides.
- Sound instance play/stop bridge.

## Evidence basis

The original JAR contains `com.soundify.sound.SoundPlayback`, `PlaybackPitch`, and `SoundPitch`. The disassembly in `bytecode/javap_batch_08.txt` shows the original playback API families: UI, local/positional, entity/player, configured-pitch, instance play/stop, and delayed playback. This stage implements the core immediate-play paths. Directional-delay scheduling and original custom replacement stream hooks are not implemented here.

## Validation

- `javac --release 21` passed against minimal temporary Minecraft API stubs for the four added source files.
- This confirms Java 21 syntax and internal references among the added classes only.
- It is **not** a compile against the real Minecraft 1.21.1 Yarn/Fabric dependencies.
- No in-game audio test has been performed.
- Actual API signatures still require validation against the real 1.21.1 mappings.

## Not yet implemented

- Original delayed playback scheduling and distance-based delay behavior.
- Full directional sound instance support.
- Custom sound replacement and dynamic stream integration.
- Sound reload / resource preparation hooks.
- Full original public overload parity.
- Full Minecraft 1.21.1 build and runtime testing.

This is a source reconstruction milestone, not an installable mod JAR.
