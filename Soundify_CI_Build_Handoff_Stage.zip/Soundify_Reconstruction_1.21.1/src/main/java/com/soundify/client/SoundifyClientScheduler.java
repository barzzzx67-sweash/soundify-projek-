package com.soundify.client;

import java.util.HashMap;
import java.util.Map;
import java.util.PriorityQueue;
import java.util.concurrent.atomic.AtomicLong;

/** Tick-based delayed task queue reconstructed from Soundify's original scheduler API. */
public final class SoundifyClientScheduler {
    private static final AtomicLong SEQUENCE = new AtomicLong();
    private static final PriorityQueue<ScheduledTask> TASKS = new PriorityQueue<>();
    private static final Map<String, ScheduledTask> KEYED_TASKS = new HashMap<>();
    private static long currentTick;

    private SoundifyClientScheduler() {}

    public static void schedule(int delayTicks, Runnable task) {
        schedule(null, delayTicks, task);
    }

    /** Scheduling with an existing key replaces the previous pending task for that key. */
    public static void schedule(String key, int delayTicks, Runnable task) {
        if (task == null) return;
        synchronized (TASKS) {
            if (key != null) {
                ScheduledTask previous = KEYED_TASKS.remove(key);
                if (previous != null) TASKS.remove(previous);
            }
            long due = currentTick + Math.max(1, delayTicks);
            ScheduledTask next = new ScheduledTask(key, due, SEQUENCE.getAndIncrement(), task);
            TASKS.add(next);
            if (key != null) KEYED_TASKS.put(key, next);
        }
    }

    public static boolean cancel(String key) {
        if (key == null) return false;
        synchronized (TASKS) {
            ScheduledTask task = KEYED_TASKS.remove(key);
            return task != null && TASKS.remove(task);
        }
    }

    /** Call exactly once from the client tick event. Tasks execute outside the queue lock. */
    public static void onClientTick() {
        synchronized (TASKS) {
            currentTick++;
        }
        while (true) {
            ScheduledTask due;
            synchronized (TASKS) {
                due = TASKS.peek();
                if (due == null || due.dueTick > currentTick) return;
                TASKS.poll();
                if (due.key != null) KEYED_TASKS.remove(due.key, due);
            }
            try {
                due.action.run();
            } catch (Throwable error) {
                System.err.println("[Soundify] Delayed task failed: " + error.getMessage());
            }
        }
    }

    public static long currentTick() {
        synchronized (TASKS) { return currentTick; }
    }

    public static int pendingTaskCount() {
        synchronized (TASKS) { return TASKS.size(); }
    }

    public static void clear() {
        synchronized (TASKS) { TASKS.clear(); KEYED_TASKS.clear(); }
    }

    private record ScheduledTask(String key, long dueTick, long sequence, Runnable action)
            implements Comparable<ScheduledTask> {
        @Override public int compareTo(ScheduledTask other) {
            int byTick = Long.compare(dueTick, other.dueTick);
            return byTick != 0 ? byTick : Long.compare(sequence, other.sequence);
        }
    }
}
