package com.soundify.client.lifecycle;

import com.soundify.client.SoundifyClientScheduler;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;

/** Client lifecycle bootstrap for reconstructed client-side utilities. */
public final class SoundifyClientStartup {
    private static boolean initialized;
    private SoundifyClientStartup() {}
    public static synchronized void initialize() {
        if (initialized) return;
        ClientTickEvents.END_CLIENT_TICK.register(client -> SoundifyClientScheduler.onClientTick());
        initialized = true;
    }
}
