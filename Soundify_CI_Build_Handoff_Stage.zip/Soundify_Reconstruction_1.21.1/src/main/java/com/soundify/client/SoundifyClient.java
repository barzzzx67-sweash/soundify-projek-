package com.soundify.client;

import net.minecraft.client.util.InputUtil;
import com.soundify.client.lifecycle.SoundifyClientStartup;
import com.soundify.feature.gui.hud.JoinHintHandler;
import com.soundify.ui.config.ConfigScreens;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

/** Client entrypoint and configuration key binding for Minecraft 1.21.1. */
public class SoundifyClient implements ClientModInitializer {
    private static final String OPEN_CONFIG_KEY_LABEL = "Open Soundify Config";
    // Minecraft 1.21.1 uses a string category; KeyBinding.Category is from newer versions.
    private static final String SOUNDIFY_CATEGORY = "key.category.soundify-reborn";
    private static final KeyBinding OPEN_CONFIG_KEY = KeyBindingHelper.registerKeyBinding(
        new KeyBinding(OPEN_CONFIG_KEY_LABEL, InputUtil.Type.KEYBOARD, 14, SOUNDIFY_CATEGORY)
    );

    public static void setOpenConfigKey(InputUtil.Key key) {
        OPEN_CONFIG_KEY.setBoundKey(key);
        KeyBinding.updateKeysByCode();
        MinecraftClient.getInstance().options.write();
    }
    public static boolean consumeOpenConfigKey() { return OPEN_CONFIG_KEY.wasPressed(); }
    public static Text openConfigKeyLabel() { return OPEN_CONFIG_KEY.getBoundKeyLocalizedText(); }
    @Override public void onInitializeClient() { SoundifyClientStartup.initialize(); }
    public static void openConfig(Screen parent) {
        JoinHintHandler.markConfigOpened();
        MinecraftClient.getInstance().setScreen(ConfigScreens.create(parent));
    }
}
