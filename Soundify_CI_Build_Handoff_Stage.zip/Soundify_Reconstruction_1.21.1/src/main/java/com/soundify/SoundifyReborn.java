package com.soundify;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/** Reconstructed from original class bytecode. */
public final class SoundifyReborn {
    public static final String MOD_ID = "soundify-reborn";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);
    private SoundifyReborn() { }
}
