package com.soundify.mixin.client.audio;

import com.soundify.sound.replacement.LoadedSoundSetIndex;
import net.minecraft.client.sound.SoundSystem;
import net.minecraft.client.sound.WeightedSoundSet;
import net.minecraft.resource.Resource;
import net.minecraft.util.Identifier;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.Map;

/** Captures the actual loaded event-set keys after vanilla's SoundList reload operation. */
@Mixin(targets = "net.minecraft.client.sound.SoundManager$SoundList")
abstract class SoundListLoadedIndexMixin {
    @Inject(method = "reload", at = @At("TAIL"))
    private void soundify$publishLoadedSoundSets(
        Map<Identifier, WeightedSoundSet> sounds,
        Map<Identifier, Resource> soundResources,
        SoundSystem soundSystem,
        CallbackInfo ci
    ) {
        LoadedSoundSetIndex.publish(sounds.keySet());
    }
}
