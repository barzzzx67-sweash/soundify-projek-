package com.soundify.mixin.client.audio;

import com.soundify.sound.replacement.MinecraftResourceManagerAdapter;
import net.minecraft.client.sound.SoundManager;
import net.minecraft.resource.ResourceManager;
import net.minecraft.util.profiler.Profiler;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.Coerce;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Rebuilds Soundify's resource index after Minecraft's sound reload apply phase. */
@Mixin(SoundManager.class)
abstract class SoundManagerResourceReloadMixin {
    @Inject(method = "apply(Lnet/minecraft/client/sound/SoundManager$SoundList;Lnet/minecraft/resource/ResourceManager;Lnet/minecraft/util/profiler/Profiler;)V", at = @At("TAIL"))
    private void soundify$indexSoundResources(@Coerce Object soundList, ResourceManager resourceManager, Profiler profiler, CallbackInfo ci) {
        MinecraftResourceManagerAdapter.rebuild(resourceManager);
    }
}
