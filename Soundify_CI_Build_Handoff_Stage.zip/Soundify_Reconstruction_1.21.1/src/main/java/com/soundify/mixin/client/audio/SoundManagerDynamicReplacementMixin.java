package com.soundify.mixin.client.audio;

import com.soundify.sound.replacement.DynamicReplacementResolver;
import com.soundify.sound.replacement.LoadedSoundSetIndex;
import net.minecraft.client.sound.SoundManager;
import net.minecraft.client.sound.WeightedSoundSet;
import net.minecraft.util.Identifier;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.Map;

/**
 * Redirects lookup of configured event IDs to an already-loaded replacement event set.
 * This deliberately only selects loaded event sets and never manufactures sound entries.
 */
@Mixin(SoundManager.class)
abstract class SoundManagerDynamicReplacementMixin {
    @Shadow @Final @SuppressWarnings("unused") private Map<Identifier, WeightedSoundSet> sounds;

    @Inject(method = "get", at = @At("HEAD"), cancellable = true)
    private void soundify$dynamicReplacement(Identifier original, CallbackInfoReturnable<WeightedSoundSet> cir) {
        if (original == null) return;
        String originalId = original.toString();
        String selected = com.soundify.sound.replacement.ReplacementResourceResolver.resolveDistinct(
                originalId, LoadedSoundSetIndex.snapshot()::contains);
        if (selected == null || selected.equals(originalId)) return;
        Identifier target = Identifier.tryParse(selected);
        if (target == null) return;
        WeightedSoundSet replacement = sounds.get(target);
        if (replacement != null) cir.setReturnValue(replacement);
    }
}
