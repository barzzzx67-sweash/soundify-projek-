package com.soundify.config;

import java.util.Collection;
import java.util.List;
import java.util.Map;

/** Reconstructed from original bytecode. */
public final class ReplacementSettings {
    private ReplacementSettings() { }
    public static void setSoundId(String soundId, String replacementId) {
        ConfigStore.settings().setReplacementSoundIds(
            soundId, replacementId == null ? List.of() : List.of(replacementId));
        SoundifyConfig.saveDebounced();
    }
    public static String customFolder(String soundId) {
        return ConfigStore.settings().customSoundFolder(soundId);
    }
    public static void setSoundIds(String soundId, Collection<String> replacementIds) {
        ConfigStore.settings().setReplacementSoundIds(soundId, replacementIds);
        SoundifyConfig.saveDebounced();
    }
    public static String soundId(String soundId) {
        return ConfigStore.settings().replacementSoundId(soundId);
    }
    public static Map<String, String> folders() {
        return ConfigStore.settings().replacementFolders();
    }
    public static List<String> soundIds(String soundId) {
        return ConfigStore.settings().replacementSoundIds(soundId);
    }
}
