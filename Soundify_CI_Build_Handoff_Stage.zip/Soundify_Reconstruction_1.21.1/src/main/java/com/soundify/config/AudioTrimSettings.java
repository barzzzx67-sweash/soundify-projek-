package com.soundify.config;

import java.nio.file.Path;

/** Reconstructed from original bytecode. */
public final class AudioTrimSettings {
    private AudioTrimSettings() { }
    public static void set(Path path, float start, float end, float fadeIn, float fadeOut) {
        ConfigStore.settings().setCustomSoundTrim(path, start, end, fadeIn, fadeOut);
        SoundifyConfig.saveDebounced();
    }
    public static SoundifyConfig.AudioTrim get(Path path) {
        return ConfigStore.settings().customSoundTrim(path);
    }
}
