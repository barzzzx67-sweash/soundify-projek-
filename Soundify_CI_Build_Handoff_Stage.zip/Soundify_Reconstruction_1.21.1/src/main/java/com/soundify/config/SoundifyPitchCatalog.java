package com.soundify.config;

import java.util.Collections;
import java.util.Map;

/**
 * Stable catalog-facing API for the reconstructed built-in pitch definitions.
 * The original bytecode stores this catalog in SoundifyCodePitchDefaults;
 * this facade gives UI/config code a descriptive entry point without changing
 * the original range semantics.
 */
public final class SoundifyPitchCatalog {
    private SoundifyPitchCatalog() { }

    /** All built-in code-pitch definitions, keyed by Soundify's storage ID. */
    public static Map<String, SoundifyConfig.PitchRange> all() {
        return SoundifyCodePitchDefaults.ranges();
    }

    /** Returns a built-in range, or null when the ID is not in the catalog. */
    public static SoundifyConfig.PitchRange find(String soundId) {
        return SoundifyCodePitchDefaults.range(soundId);
    }

    /** True when the catalog defines this ID as a built-in code-pitch entry. */
    public static boolean contains(String soundId) {
        return SoundifyCodePitchDefaults.contains(soundId);
    }

    /**
     * Returns the subset that the original implementation marks as random-range
     * entries. The map is exposed as an immutable view.
     */
    public static Map<String, SoundifyConfig.PitchRange> randomized() {
        java.util.LinkedHashMap<String, SoundifyConfig.PitchRange> result = new java.util.LinkedHashMap<>();
        for (Map.Entry<String, SoundifyConfig.PitchRange> entry : all().entrySet()) {
            if (SoundifyCodePitchDefaults.randomRange(entry.getKey()) != null) {
                result.put(entry.getKey(), entry.getValue());
            }
        }
        return Collections.unmodifiableMap(result);
    }
}
