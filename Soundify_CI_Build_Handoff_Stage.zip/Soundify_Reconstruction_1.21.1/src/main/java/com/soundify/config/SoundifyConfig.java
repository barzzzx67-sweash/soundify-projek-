package com.soundify.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.soundify.SoundifyReborn;
import com.soundify.client.SoundifyClientScheduler;
import com.soundify.sound.catalog.CustomSounds;
import com.soundify.sound.catalog.VanillaSoundCatalog;
import com.soundify.sound.replacement.CustomSoundReplacements;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.util.math.random.Random;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;
import java.util.regex.Pattern;

/**
 * Source reconstruction of Soundify 1.4.1's SoundifyConfig.
 * Recovered from the original class-file fields, method descriptors and javap bytecode.
 * This is not the original source; reconstructed behavior should be verified by compiling
 * against the matching Soundify support classes and comparing runtime behavior.
 */
public final class SoundifyConfig {
    public static final float MIN_PITCH = 0.0f;
    public static final float MAX_PITCH = 2.0f;
    public static final int DEFAULT_VOLUME = 100;
    public static final int MAX_VOLUME = 200;
    public static final String VANILLA_REPLACEMENT = "@vanilla";
    public static final String ORIGINAL_REPLACEMENT = "";
    public static final String LANGUAGE_EN_US = "en_us";
    public static final String LANGUAGE_VI_VN = "vi_vn";
    public static final int MIN_WIDE_REVERB_STRENGTH = 0;
    public static final int MAX_WIDE_REVERB_STRENGTH = 200;
    public static final int DEFAULT_WIDE_REVERB_STRENGTH = 100;
    public static final int MIN_UNDERWATER_LOWPASS_STRENGTH = 0;
    public static final int MAX_UNDERWATER_LOWPASS_STRENGTH = 200;
    public static final int DEFAULT_UNDERWATER_LOWPASS_STRENGTH = 100;
    public static final int MIN_UNDERWATER_BASS_REVERB_STRENGTH = 0;
    public static final int MAX_UNDERWATER_BASS_REVERB_STRENGTH = 200;
    public static final int DEFAULT_UNDERWATER_BASS_REVERB_STRENGTH = 100;
    public static final float MIN_UNDERWATER_PITCH_REDUCTION = 0.1f;
    public static final float MAX_UNDERWATER_PITCH_REDUCTION = 1.0f;
    public static final float DEFAULT_UNDERWATER_PITCH_REDUCTION = 0.3f;
    public static final float UNDERWATER_PITCH_REDUCTION_STEP = 0.1f;
    public static final int MIN_SWING_SOUND_COOLDOWN_MS = 100;
    public static final int MAX_SWING_SOUND_COOLDOWN_MS = 500;
    public static final int DEFAULT_SWING_SOUND_COOLDOWN_MS = 150;
    public static final int MIN_KILLSTREAK_TIMEOUT_SECONDS = 10;
    public static final int MAX_KILLSTREAK_TIMEOUT_SECONDS = 120;
    public static final int DEFAULT_KILLSTREAK_TIMEOUT_SECONDS = 30;

    private static final Pattern INVALID_CUSTOM_SOUND_ID_CHARS = Pattern.compile("[^a-z0-9._-]");
    private static final float PITCH_EPSILON = 1.0E-4f;
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().disableHtmlEscaping().create();
    private static final Path CONFIG_PATH = resolveConfigPath();
    private static long pendingSaveVersion;
    private static SoundifyConfig instance = new SoundifyConfig();

    public Map<String, Integer> soundVolumes;
    public Map<String, PitchRange> soundPitches;
    public Map<String, String> soundReplacements;
    public Map<String, List<String>> soundReplacementSelections;
    public Map<String, String> customSoundFolders;
    public Map<String, AudioTrim> customSoundTrims;
    public String replacementEditorSoundId;
    public String activeProfileName;
    public String uiLanguage;
    public boolean followVanillaGuiScale;
    public int guiScale;
    public boolean showJoinSuggestion;
    public boolean resourcePacksFirst;
    public boolean craftingSoundsEnabled;
    public boolean killstreakEnabled;
    public boolean underwaterAudioEnabled;
    public boolean wideReverbEnabled;
    public int underwaterLowpassStrength;
    public int underwaterBassReverbStrength;
    public float underwaterPitch;
    public float underwaterPitchReduction;
    public int wideReverbStrength;
    public ReverbSettings reverb;
    public int swingSoundCooldownMs;
    public int killstreakTimeoutSeconds;

    public static final class AudioTrim {
        public float fadeOut;
        public float fadeIn;
        public float start;
        public float end = 1.0f;
        public AudioTrim() {}
        public AudioTrim(float start, float end) { this.start = start; this.end = end; }
        public AudioTrim(float start, float end, float fadeIn, float fadeOut) {
            this.start = start; this.end = end; this.fadeIn = fadeIn; this.fadeOut = fadeOut;
        }
    }

    public static final class PitchRange {
        public float max = 1.0f;
        public float min = 1.0f;
        public PitchRange() {}
        public PitchRange(float min, float max) { this.min = min; this.max = max; }
    }

    public SoundifyConfig() {
        soundVolumes = new LinkedHashMap<>();
        soundPitches = new LinkedHashMap<>();
        soundReplacements = new LinkedHashMap<>();
        soundReplacementSelections = new LinkedHashMap<>();
        customSoundFolders = new LinkedHashMap<>();
        customSoundTrims = new LinkedHashMap<>();
        replacementEditorSoundId = "";
        activeProfileName = "";
        uiLanguage = "";
        followVanillaGuiScale = true;
        guiScale = 2;
        showJoinSuggestion = true;
        resourcePacksFirst = true;
        craftingSoundsEnabled = true;
        killstreakEnabled = true;
        underwaterAudioEnabled = true;
        wideReverbEnabled = true;
        underwaterLowpassStrength = 100;
        underwaterBassReverbStrength = 100;
        underwaterPitch = 0.3f;
        underwaterPitchReduction = 0.3f;
        wideReverbStrength = 100;
        reverb = new ReverbSettings();
        swingSoundCooldownMs = 150;
        killstreakTimeoutSeconds = 30;
    }

    public static SoundifyConfig get() { return instance; }

    public static void apply(SoundifyConfig config) {
        instance = config == null ? new SoundifyConfig() : config;
        instance.ensureCollections();
        CustomSoundReplacements.invalidateReplacementCache();
    }

    public static String storageKeyForInternalUse(String id) {
        if (id != null && id.startsWith("soundify-reborn:")) return id.substring("soundify-reborn:".length());
        return id == null ? "" : id;
    }
    private static String storageKey(String id) { return storageKeyForInternalUse(id); }

    public int getVolume(String id) { return volumes().getOrDefault(storageKey(id), volumes().getOrDefault(id, DEFAULT_VOLUME)); }
    public void setVolume(String id, int volume) {
        int clamped = Math.max(0, Math.min(MAX_VOLUME, volume));
        String key = storageKey(id);
        if (clamped == DEFAULT_VOLUME) {
            volumes().remove(key);
            volumes().remove(id);
        } else {
            volumes().put(key, clamped);
        }
    }
    public float getVolumeMultiplier(String id) { return getVolume(id) / 100.0f; }
    private Map<String,Integer> volumes() { if (soundVolumes == null) soundVolumes = new LinkedHashMap<>(); return soundVolumes; }

    public PitchRange getPitchRange(String id) {
        String key = storageKey(id);
        PitchRange configured = pitches().get(key);
        return configured == null ? defaultPitchRange(key) : sanitizePitchRange(configured.min, configured.max);
    }
    private PitchRange configuredPitchRange(String id) { return pitches().get(storageKey(id)); }
    private Map<String,PitchRange> pitches() { if (soundPitches == null) soundPitches = new LinkedHashMap<>(); return soundPitches; }
    public boolean hasPitchOverride(String id) { return configuredPitchRange(id) != null; }
    public void setPitchRange(String id, float min, float max) {
        String key = storageKey(id);
        PitchRange clean = sanitizePitchRange(min, max);
        PitchRange defaults = defaultPitchRange(key);
        if (samePitch(clean.min, defaults.min) && samePitch(clean.max, defaults.max)) {
            pitches().remove(key);
            pitches().remove(id);
        } else {
            pitches().put(key, clean);
        }
    }
    public float samplePitch(String id) { return sample(getPitchRange(id)); }
    private static float sample(PitchRange range) {
        if (samePitch(range.min, range.max)) return range.min;
        return range.min + java.util.concurrent.ThreadLocalRandom.current().nextFloat() * (range.max - range.min);
    }
    private static float sample(PitchRange range, Random random) {
        if (samePitch(range.min, range.max)) return range.min;
        return range.min + random.nextFloat() * (range.max - range.min);
    }
    private static boolean samePitch(float a, float b) { return Math.abs(a - b) < PITCH_EPSILON; }
    public float samplePitchMultiplier(String id) { return samplePitch(id); }
    public float sampleCodePitch(String id) { return sampleCodePitch(id, Random.create()); }
    public float sampleCodePitch(String id, Random random) {
        rejectDynamicCodePitch(id);
        return sample(getPitchRange(id), random == null ? Random.create() : random);
    }
    public float applyPitchOverride(String id, float original) {
        PitchRange range = configuredPitchRange(id);
        return range == null ? original : sample(range);
    }
    public float mapCodePitchOverride(String id, float value, float min, float max) {
        rejectDynamicCodePitch(id);
        if (!hasPitchOverride(id)) return value;
        return mapCodePitch(id, value, min, max);
    }
    public float mapCodePitch(String id, float value, float min, float max) {
        PitchRange range = getPitchRange(id);
        if (samePitch(min, max)) return range.min;
        float t = Math.max(0.0f, Math.min(1.0f, (value - min) / (max - min)));
        return range.min + t * (range.max - range.min);
    }
    private static void rejectDynamicCodePitch(String id) {
        if (SoundifyCodePitchDefaults.isDynamic(id)) throw new IllegalArgumentException("Dynamic code pitch cannot be overridden: " + id);
    }
    private static float defaultPitchCenter(String id) {
        String registryId = id;
        if (id != null && id.startsWith("soundify-reborn:")) {
            registryId = id.substring("soundify-reborn:".length());
        }
        try {
            if (com.soundify.sound.catalog.SoundEventRegistry.get(registryId) == null) return 1.0f;
            return (CustomSounds.defaultMinPitch(id) + CustomSounds.defaultMaxPitch(id)) / 2.0f;
        } catch (LinkageError | RuntimeException ex) {
            return 1.0f;
        }
    }

    private static PitchRange defaultPitchRange(String id) {
        try {
            PitchRange range = SoundifyCodePitchDefaults.range(id);
            if (range != null) return sanitizePitchRange(range.min, range.max);
            return sanitizePitchRange(CustomSounds.defaultMinPitch(id), CustomSounds.defaultMaxPitch(id));
        } catch (LinkageError | RuntimeException ex) { return new PitchRange(1.0f, 1.0f); }
    }
    private static PitchRange sanitizePitchRange(float min, float max) {
        float a = clampPitch(min), b = clampPitch(max);
        if (a > b) { float t = a; a = b; b = t; }
        return new PitchRange(a, b);
    }
    private static float clampPitch(float value) { return Math.max(MIN_PITCH, Math.min(MAX_PITCH, value)); }

    public int wideReverbStrength() { return clampWideReverbStrength(wideReverbStrength); }
    public void setWideReverbStrength(int value) { wideReverbStrength = clampWideReverbStrength(value); }
    public boolean wideReverbEnabled() { return wideReverbEnabled; }
    public void setWideReverbEnabled(boolean value) { wideReverbEnabled = value; }
    public float wideReverbStrengthMultiplier() { return wideReverbStrength() / 100.0f; }
    private static int clampWideReverbStrength(int v) { return Math.max(0, Math.min(200, v)); }

    public int underwaterLowpassStrength() { return clampUnderwaterLowpassStrength(underwaterLowpassStrength); }
    public void setUnderwaterLowpassStrength(int value) { underwaterLowpassStrength = clampUnderwaterLowpassStrength(value); }
    public float underwaterLowpassStrengthMultiplier() { return underwaterLowpassStrength() / 100.0f; }
    private static int clampUnderwaterLowpassStrength(int v) { return Math.max(0, Math.min(200, v)); }
    public int underwaterBassReverbStrength() { return clampUnderwaterBassReverbStrength(underwaterBassReverbStrength); }
    public void setUnderwaterBassReverbStrength(int value) { underwaterBassReverbStrength = clampUnderwaterBassReverbStrength(value); }
    public float underwaterBassReverbStrengthMultiplier() { return underwaterBassReverbStrength() / 100.0f; }
    private static int clampUnderwaterBassReverbStrength(int v) { return Math.max(0, Math.min(200, v)); }
    public float underwaterPitchReduction() { return sanitizeUnderwaterPitchReduction(underwaterPitchReduction); }
    public void setUnderwaterPitchReduction(float v) { underwaterPitchReduction = sanitizeUnderwaterPitchReduction(v); }
    private static float sanitizeUnderwaterPitchReduction(float v) {
        float c = Math.max(MIN_UNDERWATER_PITCH_REDUCTION, Math.min(MAX_UNDERWATER_PITCH_REDUCTION, v));
        return Math.round(c / UNDERWATER_PITCH_REDUCTION_STEP) * UNDERWATER_PITCH_REDUCTION_STEP;
    }
    public boolean underwaterAudioEnabled() { return underwaterAudioEnabled; }
    public void setUnderwaterAudioEnabled(boolean v) { underwaterAudioEnabled = v; }
    public boolean craftingSoundsEnabled() { return craftingSoundsEnabled; }
    public void setCraftingSoundsEnabled(boolean v) { craftingSoundsEnabled = v; }
    public boolean killstreakEnabled() { return killstreakEnabled; }
    public void setKillstreakEnabled(boolean v) { killstreakEnabled = v; }
    public int killstreakTimeoutSeconds() { return clampKillstreakTimeout(killstreakTimeoutSeconds); }
    public void setKillstreakTimeoutSeconds(int v) { killstreakTimeoutSeconds = clampKillstreakTimeout(v); }
    private static int clampKillstreakTimeout(int v) { return Math.max(10, Math.min(120, v)); }
    public int swingSoundCooldownMs() { return clampSwingSoundCooldown(swingSoundCooldownMs); }
    public void setSwingSoundCooldownMs(int v) { swingSoundCooldownMs = clampSwingSoundCooldown(v); }
    private static int clampSwingSoundCooldown(int v) { return Math.max(100, Math.min(500, v)); }
    public int guiScale() { return guiScale; }
    public void setGuiScale(int v) { guiScale = Math.max(0, Math.min(4, v)); }
    public boolean followVanillaGuiScale() { return followVanillaGuiScale; }
    public void setFollowVanillaGuiScale(boolean v) { followVanillaGuiScale = v; }
    public boolean showJoinSuggestion() { return showJoinSuggestion; }
    public void setShowJoinSuggestion(boolean v) { showJoinSuggestion = v; }
    public String getUiLanguage() { return normalizeUiLanguage(uiLanguage); }
    public void setUiLanguage(String value) { uiLanguage = normalizeUiLanguage(value); }
    private static String normalizeUiLanguage(String value) {
        if (value == null || value.isBlank()) return LANGUAGE_EN_US;
        String v = value.toLowerCase(Locale.ROOT).replace('-', '_');
        return v.equals(LANGUAGE_VI_VN) ? LANGUAGE_VI_VN : LANGUAGE_EN_US;
    }
    public String getActiveProfileName() { return activeProfileName == null ? "" : activeProfileName; }
    public void setActiveProfileName(String value) { activeProfileName = value == null ? "" : value; }
    public String getReplacementEditorSoundId(String fallback) { return replacementEditorSoundId == null || replacementEditorSoundId.isBlank() ? fallback : replacementEditorSoundId; }
    public void setReplacementEditorSoundId(String value) { replacementEditorSoundId = value == null ? "" : value; }
    public ReverbSettings reverb() { if (reverb == null) reverb = new ReverbSettings(); return reverb; }

    private Map<String,String> replacements() { if (soundReplacements == null) soundReplacements = new LinkedHashMap<>(); return soundReplacements; }
    private Map<String,List<String>> replacementSelections() { if (soundReplacementSelections == null) soundReplacementSelections = new LinkedHashMap<>(); return soundReplacementSelections; }
    private Map<String,String> customSounds() { if (customSoundFolders == null) customSoundFolders = new LinkedHashMap<>(); return customSoundFolders; }
    private Map<String,AudioTrim> trims() { if (customSoundTrims == null) customSoundTrims = new LinkedHashMap<>(); return customSoundTrims; }
    public Map<String,String> customSoundFolders() { return customSounds(); }
    public Map<String,String> replacementFolders() { return replacements(); }
    public Map<String,List<String>> replacementSources() { return replacementSelections(); }
    public String getCustomSoundFolder(String id) { return customSounds().getOrDefault(id, ""); }
    public String getReplacementFolder(String id) {
        String key = storageKey(id);
        String replacement = replacements().getOrDefault(key, replacements().getOrDefault(id, ""));
        if (replacement == null || replacement.isBlank() || VANILLA_REPLACEMENT.equals(replacement)) return "";
        return customSounds().getOrDefault(replacement, replacement);
    }
    public void setReplacementFolder(String id, String folder) { replacements().put(storageKey(id), folder == null ? "" : folder); }
    public String addCustomSound(String folder) {
        String existing = customSoundIdForFolder(folder);
        if (!existing.isBlank()) return existing;
        String id = uniqueCustomSoundId(folder);
        customSounds().put(id, folder);
        CustomSoundReplacements.invalidateReplacementCache();
        return id;
    }
    private String uniqueCustomSoundId(String folder) {
        String base = customSoundIdBase(folder);
        String candidate = base;
        int suffix = 2;
        while (customSounds().containsKey(candidate)) candidate = base + suffix++;
        return candidate;
    }
    private static String customSoundIdBase(String folder) {
        String name = folder;
        try {
            Path fileName = Path.of(folder).getFileName();
            if (fileName != null) name = fileName.toString();
        } catch (java.nio.file.InvalidPathException ignored) { }
        String id = INVALID_CUSTOM_SOUND_ID_CHARS.matcher(name.toLowerCase(Locale.ROOT).trim())
                .replaceAll("_").replaceAll("_+", "_").replaceAll("^_+|_+$", "");
        return id.isBlank() ? "custom_sound" : id;
    }
    public void removeCustomSound(String id) {
        customSounds().remove(id);
        replacements().entrySet().removeIf(entry -> id.equals(entry.getValue()));
        replacementSelections().replaceAll((key, values) -> values == null ? List.of()
                : values.stream().filter(value -> !id.equals(value)).distinct().toList());
        replacementSelections().entrySet().removeIf(entry -> entry.getValue() == null || entry.getValue().isEmpty());
        CustomSoundReplacements.invalidateReplacementCache();
    }

    public String customSoundIdForFolder(String folder) {
        deduplicateCustomSounds(); String normalized = normalizeFolder(folder);
        if (normalized.isBlank()) return "";
        for (Map.Entry<String,String> e : customSounds().entrySet()) if (normalized.equals(normalizeFolder(e.getValue()))) return e.getKey();
        return "";
    }
    public void setCustomSoundFolder(String id, String folder) {
        if (id == null || id.isBlank() || folder == null || folder.isBlank()) return;
        String existingId = customSoundIdForFolder(folder);
        if (!existingId.isBlank() && !existingId.equals(id)) {
            replaceCustomSoundReferences(id, existingId);
            customSounds().remove(id);
            CustomSoundReplacements.invalidateReplacementCache();
            return;
        }
        customSounds().put(id, folder);
        deduplicateCustomSounds();
        CustomSoundReplacements.invalidateReplacementCache();
    }

    private static String normalizeFolder(String value) {
        if (value == null || value.isBlank()) return "";
        try {
            Path path = Path.of(value).toAbsolutePath().normalize();
            String normalized = Files.exists(path) ? path.toRealPath().toString() : path.toString();
            boolean windows = System.getProperty("os.name", "").toLowerCase(Locale.ROOT).contains("windows");
            return windows ? normalized.toLowerCase(Locale.ROOT) : normalized;
        } catch (java.nio.file.InvalidPathException ex) {
            return value.trim();
        } catch (IOException ex) {
            return Path.of(value).toAbsolutePath().normalize().toString();
        }
    }

    private void deduplicateCustomSounds() {
        Map<String, String> sounds = customSounds();
        if (sounds.isEmpty()) return;
        Map<String, String> firstIdByFolder = new LinkedHashMap<>();
        Map<String, String> duplicateIds = new LinkedHashMap<>();
        Map<String, String> cleaned = new LinkedHashMap<>();
        for (Map.Entry<String, String> entry : sounds.entrySet()) {
            String id = entry.getKey();
            String originalFolder = entry.getValue();
            String folder = normalizeFolder(originalFolder);
            if (id == null || id.isBlank() || folder.isBlank()) continue;
            String firstId = firstIdByFolder.get(folder);
            if (firstId == null) {
                firstIdByFolder.put(folder, id);
                cleaned.put(id, originalFolder);
            } else {
                duplicateIds.put(id, firstId);
            }
        }
        if (duplicateIds.isEmpty() && cleaned.size() == sounds.size()) return;
        customSoundFolders = cleaned;
        for (Map.Entry<String, String> duplicate : duplicateIds.entrySet()) {
            replaceCustomSoundReferences(duplicate.getKey(), duplicate.getValue());
        }
    }
    public List<String> getReplacementSources(String id) {
        if (isVanillaReplacement(id)) return List.of();
        List<String> ids = getReplacementCustomSoundIds(id);
        if (!ids.isEmpty()) {
            return ids.stream().map(this::getCustomSoundFolder)
                    .filter(folder -> folder != null && !folder.isBlank()).distinct().toList();
        }
        String legacyFolder = getReplacementFolder(id);
        return legacyFolder == null || legacyFolder.isBlank() ? List.of() : List.of(legacyFolder);
    }
    public List<String> getReplacementCustomSoundIds(String id) {
        String key = storageKey(id);
        List<String> configured = replacementSelections().get(key);
        if (configured == null) configured = replacementSelections().get(id);
        if (configured != null) {
            if (supportsVanillaReplacement(key) && configured.contains(VANILLA_REPLACEMENT)) {
                return List.of(VANILLA_REPLACEMENT);
            }
            return configured.stream().filter(customSounds()::containsKey).distinct().toList();
        }
        String legacy = replacements().getOrDefault(key, replacements().getOrDefault(id, ""));
        if (customSounds().containsKey(legacy) || (supportsVanillaReplacement(key) && VANILLA_REPLACEMENT.equals(legacy))) {
            return List.of(legacy);
        }
        return List.of();
    }
    public String getReplacementCustomSoundId(String id) { List<String> ids = getReplacementCustomSoundIds(id); return ids.isEmpty() ? "" : ids.get(0); }
    public void setReplacementCustomSound(String id, String customId) { setReplacementCustomSounds(id, customId == null || customId.isBlank() ? List.of() : List.of(customId)); }
    public void setReplacementCustomSounds(String id, Collection<String> ids) {
        String key = storageKey(id);
        List<String> clean = ids == null ? List.of() : ids.stream()
                .filter(candidate -> candidate != null && customSounds().containsKey(candidate))
                .distinct().toList();
        // The original implementation treats vanilla replacement as exclusive.
        if (supportsVanillaReplacement(key) && ids != null && ids.contains(VANILLA_REPLACEMENT)) {
            clean = List.of(VANILLA_REPLACEMENT);
        }
        if (clean.isEmpty()) {
            clearReplacement(key);
            return;
        }
        replacements().remove(id);
        replacementSelections().remove(id);
        replacements().put(key, clean.get(0));
        replacementSelections().put(key, clean);
        CustomSoundReplacements.invalidateReplacementCache();
    }
    public void clearReplacement(String id) {
        replacements().remove(storageKey(id));
        replacements().remove(id);
        replacementSelections().remove(storageKey(id));
        replacementSelections().remove(id);
        CustomSoundReplacements.invalidateReplacementCache();
    }
    public boolean isVanillaReplacement(String id) {
        String key = storageKey(id);
        if (!supportsVanillaReplacement(key)) return false;
        List<String> selections = replacementSelections().get(key);
        if (selections == null) return VANILLA_REPLACEMENT.equals(replacements().get(key));
        return selections.contains(VANILLA_REPLACEMENT);
    }
    public static boolean supportsVanillaReplacement(String id) { return VanillaSoundCatalog.contains(id); }

    public AudioTrim getCustomSoundTrim(Path path) { return trims().get(normalizeFile(path)); }
    public void setCustomSoundTrim(Path path, float start, float end) { setCustomSoundTrim(path, start, end, 0.0f, 0.0f); }
    public void setCustomSoundTrim(Path path, float start, float end, float fadeIn, float fadeOut) {
        String key = normalizeFile(path);
        if (key.isBlank()) return;
        AudioTrim trim = sanitizeTrim(start, end, fadeIn, fadeOut);
        if (trim.start <= 0.0f && trim.end >= 1.0f && trim.fadeIn <= 0.0f && trim.fadeOut <= 0.0f) {
            trims().remove(key);
        } else {
            trims().put(key, trim);
        }
        CustomSoundReplacements.invalidateReplacementCache();
    }
    private static AudioTrim sanitizeTrim(float start, float end, float fadeIn, float fadeOut) {
        float s = clampProgress(start);
        float e = clampProgress(end);
        if (e < s) { float swap = s; s = e; e = swap; }
        return new AudioTrim(s, e, clampFade(fadeIn), clampFade(fadeOut));
    }
    private static float clampProgress(float value) {
        return Float.isFinite(value) ? Math.max(0.0f, Math.min(1.0f, value)) : 0.0f;
    }
    private static float clampFade(float value) {
        return Float.isFinite(value) ? Math.max(0.0f, Math.min(5.0f, value)) : 0.0f;
    }
    private static String normalizeFile(Path path) {
        if (path == null) return "";
        try {
            Path normalized = path.toAbsolutePath().normalize();
            if (Files.exists(normalized)) normalized = normalized.toRealPath();
            String value = normalized.toString();
            return System.getProperty("os.name", "").toLowerCase(Locale.ROOT).contains("windows")
                    ? value.toLowerCase(Locale.ROOT) : value;
        } catch (java.nio.file.InvalidPathException | IOException ex) {
            return path.toAbsolutePath().normalize().toString();
        }
    }

    private void ensureCollections() {
        volumes(); pitches(); replacements(); replacementSelections(); customSounds(); trims();
        deduplicateCustomSounds();
        migrateAnvilDestroySettings();
        if (replacementEditorSoundId == null) replacementEditorSoundId = "";
        if (activeProfileName == null) activeProfileName = "";
        uiLanguage = normalizeUiLanguage(uiLanguage);
        guiScale = Math.max(0, Math.min(4, guiScale));
        underwaterLowpassStrength = clampUnderwaterLowpassStrength(underwaterLowpassStrength);
        underwaterBassReverbStrength = clampUnderwaterBassReverbStrength(underwaterBassReverbStrength);
        if (Math.abs(underwaterPitchReduction - DEFAULT_UNDERWATER_PITCH_REDUCTION) < PITCH_EPSILON
                && underwaterPitch > underwaterPitchReduction) {
            underwaterPitchReduction = 1.0f - underwaterPitch;
        }
        underwaterPitchReduction = sanitizeUnderwaterPitchReduction(underwaterPitchReduction);
        underwaterPitch = 1.0f - underwaterPitchReduction;
        wideReverbStrength = clampWideReverbStrength(wideReverbStrength);
        swingSoundCooldownMs = clampSwingSoundCooldown(swingSoundCooldownMs);
        killstreakTimeoutSeconds = clampKillstreakTimeout(killstreakTimeoutSeconds);
        if (reverb == null) reverb = new ReverbSettings();
    }
    public static void load() {
        if (!Files.isRegularFile(CONFIG_PATH)) { instance = new SoundifyConfig(); CustomSoundReplacements.invalidateReplacementCache(); save(); return; }
        try (BufferedReader reader = Files.newBufferedReader(CONFIG_PATH)) {
            SoundifyConfig loaded = GSON.fromJson(reader, SoundifyConfig.class);
            instance = loaded == null ? new SoundifyConfig() : loaded;
            instance.ensureCollections();
            CustomSoundReplacements.invalidateReplacementCache();
        } catch (Exception ex) {
            SoundifyReborn.LOGGER.warn("Failed to load Soundify config, using defaults", ex);
            instance = new SoundifyConfig();
            CustomSoundReplacements.invalidateReplacementCache();
        }
    }
    public static void save() {
        pendingSaveVersion++;
        try {
            Files.createDirectories(CONFIG_PATH.getParent());
            get().ensureCollections();
            try (BufferedWriter writer = Files.newBufferedWriter(CONFIG_PATH)) { GSON.toJson(get(), writer); }
        } catch (IOException ex) { SoundifyReborn.LOGGER.warn("Failed to save Soundify config", ex); }
    }
    public static void saveDebounced() {
        long version = ++pendingSaveVersion;
        SoundifyClientScheduler.schedule("soundify-config-save", 5, () -> { if (pendingSaveVersion == version) save(); });
    }
    private static Path resolveConfigPath() {
        try { Path dir = FabricLoader.getInstance().getConfigDir(); if (dir != null) return dir.resolve("soundify-reborn.json"); }
        catch (RuntimeException ignored) { }
        return Path.of("config").resolve("soundify-reborn.json");
    }

    private void replaceCustomSoundReferences(String oldId, String newId) {
        replacements().replaceAll((key, value) -> oldId.equals(value) ? newId : value);
        replacementSelections().replaceAll((key, values) -> values == null ? List.of()
                : values.stream().map(value -> oldId.equals(value) ? newId : value).distinct().toList());
    }

    private static void moveSoundSetting(Map<String, ?> map, String oldKey, String newKey) {
        if (map == null) return;
        @SuppressWarnings("unchecked") Map<String, Object> values = (Map<String, Object>) map;
        Object oldValue = values.remove(oldKey);
        if (oldValue != null) values.putIfAbsent(newKey, oldValue);
    }

    private void migrateAnvilDestroySettings() {
        String oldId = "minecraft:block.anvil.break";
        String newId = "minecraft:block.anvil.destroy";
        moveSoundSetting(soundVolumes, oldId, newId);
        moveSoundSetting(soundPitches, oldId, newId);
        moveSoundSetting(soundReplacements, oldId, newId);
        moveSoundSetting(soundReplacementSelections, oldId, newId);
        if (oldId.equals(replacementEditorSoundId)) replacementEditorSoundId = newId;
    }


}
