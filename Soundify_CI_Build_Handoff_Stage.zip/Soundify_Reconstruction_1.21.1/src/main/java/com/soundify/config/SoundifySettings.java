package com.soundify.config;

import java.nio.file.Path;
import java.util.Collection;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Reconstructed from the original bytecode; delegates to SoundifyConfig. */
public final class SoundifySettings {
    private final SoundifyConfig config;

    SoundifySettings(SoundifyConfig config) { this.config = config; }

    public float mapCodePitch(String soundId, float basePitch, float min, float max) {
        return config.mapCodePitch(soundId, basePitch, min, max);
    }
    public List<String> replacementSoundIds(String soundId) {
        return config.getReplacementCustomSoundIds(soundId);
    }
    public Map<String, String> replacementFolders() {
        return snapshot(config.replacementFolders());
    }
    public void setCustomSoundTrim(Path path, float start, float end, float fadeIn, float fadeOut) {
        config.setCustomSoundTrim(path, start, end, fadeIn, fadeOut);
    }
    public SoundifyConfig.PitchRange pitchRange(String soundId) {
        return config.getPitchRange(soundId);
    }
    public SoundifyConfig.AudioTrim customSoundTrim(Path path) {
        return config.getCustomSoundTrim(path);
    }
    public Map<String, String> customSoundFolders() {
        return snapshot(config.customSoundFolders());
    }
    public void setPitchRange(String soundId, float min, float max) {
        config.setPitchRange(soundId, min, max);
    }
    public String customSoundFolder(String soundId) {
        return config.getCustomSoundFolder(soundId);
    }
    public float volumeMultiplier(String soundId) {
        return config.getVolumeMultiplier(soundId);
    }
    public Map<String, List<String>> replacementSources() {
        return snapshot(config.replacementSources());
    }
    public float samplePitch(String soundId) { return config.samplePitch(soundId); }
    public void setReplacementSoundIds(String soundId, Collection<String> values) {
        config.setReplacementCustomSounds(soundId, values);
    }
    public int replacementHash() {
        return 31 * replacementSources().hashCode() + config.soundReplacements.hashCode();
    }
    public String replacementSoundId(String soundId) {
        return config.getReplacementCustomSoundId(soundId);
    }
    public int volume(String soundId) { return config.getVolume(soundId); }
    private static <K, V> Map<K, V> snapshot(Map<K, V> source) {
        return Collections.unmodifiableMap(new LinkedHashMap<>(source));
    }
    public void setVolume(String soundId, int volume) { config.setVolume(soundId, volume); }
}
