package com.soundify.config;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Reconstructed from Soundify 1.4.1+26.3 bytecode (javap_batch_01.txt).
 *
 * This class preserves the original built-in code-pitch ranges and the separate
 * subset of ranges which are explicitly randomized by the code-pitch system.
 * It intentionally does not depend on Minecraft APIs and is Java 21 compatible.
 */
public final class SoundifyCodePitchDefaults {
    private static final Map<String, SoundifyConfig.PitchRange> RANDOM_RANGES;
    private static final Map<String, SoundifyConfig.PitchRange> RANGES;

    static {
        Map<String, SoundifyConfig.PitchRange> ranges = new LinkedHashMap<>();
        Map<String, SoundifyConfig.PitchRange> randomRanges = new LinkedHashMap<>();

        addRandom(ranges, randomRanges, "water_crawl", 0.9f, 1.1f);
        addRandom(ranges, randomRanges, "headhit", 0.9f, 1.1f);
        addRandom(ranges, randomRanges, "elytra_use", 0.9f, 1.1f);
        addRandom(ranges, randomRanges, "hold_item", 0.8f, 1.3f);
        addRandom(ranges, randomRanges, "place_inventory_slot", 0.9f, 1.1f);
        addRandom(ranges, randomRanges, "swap_hand", 0.9f, 1.1f);
        addRandom(ranges, randomRanges, "reject", 0.95f, 1.05f);
        addRandom(ranges, randomRanges, "accept", 0.95f, 1.05f);
        addRandom(ranges, randomRanges, "player_jumpboost", 0.8f, 1.0f);
        addRandom(ranges, randomRanges, "sneak", 0.8f, 1.2f);
        addRandom(ranges, randomRanges, "stand", 0.8f, 1.2f);
        addRandom(ranges, randomRanges, "mace_windup", 0.9f, 1.1f);
        addRandom(ranges, randomRanges, "mace_attack", 0.9f, 1.1f);
        addRandom(ranges, randomRanges, "shield_use", 0.9f, 1.1f);
        addRandom(ranges, randomRanges, "sweep_attack", 0.9f, 1.1f);
        addRandom(ranges, randomRanges, "metal_dig", 0.7f, 1.1f);
        addRandom(ranges, randomRanges, "crystal_boom", 0.95f, 1.1f);
        addRandom(ranges, randomRanges, "type", 0.8f, 1.1f);
        addRandom(ranges, randomRanges, "backtype", 0.8f, 1.1f);
        addRandom(ranges, randomRanges, "arrow_hit", 0.9f, 1.1f);
        addRandom(ranges, randomRanges, "flame_hit", 0.9f, 1.1f);
        add(ranges, "arrow_hit_player", 1.0f, 2.0f);

        RANGES = Collections.unmodifiableMap(ranges);
        RANDOM_RANGES = Collections.unmodifiableMap(randomRanges);
    }

    private SoundifyCodePitchDefaults() { }

    public static boolean isDynamic(String id) {
        return contains(id) && randomRange(id) == null;
    }

    public static boolean contains(String id) {
        return range(id) != null;
    }

    public static Map<String, SoundifyConfig.PitchRange> ranges() {
        return RANGES;
    }

    public static SoundifyConfig.PitchRange randomRange(String id) {
        return RANDOM_RANGES.get(SoundifyConfig.storageKeyForInternalUse(id));
    }

    public static SoundifyConfig.PitchRange range(String id) {
        return RANGES.get(SoundifyConfig.storageKeyForInternalUse(id));
    }

    private static void addRandom(
            Map<String, SoundifyConfig.PitchRange> ranges,
            Map<String, SoundifyConfig.PitchRange> randomRanges,
            String id, float min, float max) {
        add(ranges, id, min, max);
        add(randomRanges, id, min, max);
    }

    private static void add(Map<String, SoundifyConfig.PitchRange> target,
                            String id, float min, float max) {
        target.put(id, new SoundifyConfig.PitchRange(min, max));
    }
}
