package com.soundify.config;

import net.minecraft.client.gui.screen.Screen;
import com.soundify.ui.config.ConfigScreens;

/** Reconstructed from original bytecode. */
public final class ConfigView {
    private ConfigView() { }
    public static Screen create(Screen parent) { return ConfigScreens.create(parent); }
    public static boolean isConfigScreen(Screen screen) { return ConfigScreens.isConfigScreen(screen); }
}
