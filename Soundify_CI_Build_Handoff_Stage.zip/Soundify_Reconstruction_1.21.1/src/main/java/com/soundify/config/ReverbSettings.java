package com.soundify.config;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Reconstructed reverb configuration model from the original Soundify 1.4.1
 * class-file API and bytecode. Kept free of Minecraft types so configuration
 * data can be loaded and validated independently from the audio backend.
 */
public final class ReverbSettings {
    public float materialInfluence;
    public Profile water;
    public Map<String, Material> materials;
    public Quality quality;
    public Profile air;
    public float transitionSeconds;
    public float environmentInfluence;

    public static final class Material {
        public float reflection;
        public float absorption;

        public Material(float reflection, float absorption) {
            this.reflection = reflection;
            this.absorption = absorption;
        }
    }

    public enum MaterialGroup {
        STONE("Stone", 0.85f, 0.18f),
        METAL("Metal", 0.95f, 0.08f),
        GLASS("Glass", 0.80f, 0.12f),
        WOOD("Wood", 0.60f, 0.40f),
        EARTH("Earth / sand", 0.35f, 0.65f),
        SOFT("Wool / foliage", 0.12f, 0.90f),
        OTHER("Other materials", 0.50f, 0.40f);

        public final String label;
        public final float reflection;
        public final float absorption;

        MaterialGroup(String label, float reflection, float absorption) {
            this.label = label;
            this.reflection = reflection;
            this.absorption = absorption;
        }
    }

    public enum Parameter {
        GAIN("Reverb level", 0.0f, 1.0f, 0.01f, 0.32f, 0.25f, ""),
        DECAY("Tail length", 0.1f, 20.0f, 0.1f, 2.8f, 2.2f, " s"),
        BRIGHTNESS("Brightness", 0.01f, 1.0f, 0.01f, 0.8f, 0.16f, ""),
        DENSITY("Density", 0.0f, 1.0f, 0.01f, 0.85f, 0.95f, ""),
        DIFFUSION("Diffusion", 0.0f, 1.0f, 0.01f, 0.9f, 0.95f, ""),
        EARLY_GAIN("Early reflections", 0.0f, 3.16f, 0.01f, 0.35f, 0.12f, ""),
        EARLY_DELAY("Reflection delay", 0.0f, 0.3f, 0.001f, 0.015f, 0.025f, " s"),
        LATE_GAIN("Late reflections", 0.0f, 4.0f, 0.05f, 1.3f, 1.5f, ""),
        LATE_DELAY("Tail delay", 0.0f, 0.1f, 0.001f, 0.025f, 0.04f, " s"),
        BASS("Bass level", 0.0f, 1.0f, 0.01f, 1.0f, 1.0f, ""),
        HF_DECAY("Treble decay ratio", 0.1f, 2.0f, 0.05f, 0.75f, 0.3f, "x"),
        LF_DECAY("Bass decay ratio", 0.1f, 2.0f, 0.05f, 1.0f, 1.4f, "x");

        public final String label;
        public final float min;
        public final float max;
        public final float step;
        public final float airDefault;
        public final float waterDefault;
        public final String unit;

        Parameter(String label, float min, float max, float step,
                  float airDefault, float waterDefault, String unit) {
            this.label = label;
            this.min = min;
            this.max = max;
            this.step = step;
            this.airDefault = airDefault;
            this.waterDefault = waterDefault;
            this.unit = unit;
        }
    }

    public enum Preset {
        NATURAL,
        SPATIAL,
        CINEMATIC,
        CUSTOM
    }

    public static final class Profile {
        public Preset preset;
        public Map<String, Float> values;

        public Profile() {
            preset = Preset.SPATIAL;
            values = new LinkedHashMap<>();
        }

        public void set(Parameter parameter, float value, boolean underwater) {
            if (values == null) values = new LinkedHashMap<>();
            float fallback = underwater ? parameter.waterDefault : parameter.airDefault;
            values.put(parameter.name(), bounded(value, parameter.min, parameter.max, fallback));
            preset = Preset.CUSTOM;
        }

        public void apply(Preset requested, boolean underwater) {
            values = new LinkedHashMap<>();
            if (requested == Preset.NATURAL || requested == Preset.CINEMATIC) {
                boolean natural = requested == Preset.NATURAL;
                float gainScale = natural ? 0.65f : 1.4f;
                float decayScale = natural ? 0.65f : 1.7f;
                set(Parameter.GAIN, get(Parameter.GAIN, underwater) * gainScale, underwater);
                set(Parameter.DECAY, get(Parameter.DECAY, underwater) * decayScale, underwater);
                set(Parameter.LATE_GAIN, natural ? 1.0f : 1.9f, underwater);
            }
            preset = requested == null || requested == Preset.CUSTOM ? Preset.SPATIAL : requested;
        }

        public float get(Parameter parameter, boolean underwater) {
            Float stored = values == null ? null : values.get(parameter.name());
            float fallback = underwater ? parameter.waterDefault : parameter.airDefault;
            return bounded(stored == null ? fallback : stored,
                    parameter.min, parameter.max, fallback);
        }
    }

    public enum Quality {
        LOW(12, 32, 10, 1),
        BALANCED(24, 48, 5, 3),
        HIGH(40, 64, 3, 6);

        public final int rays;
        public final int distance;
        public final int intervalTicks;
        public final int sourceChecks;

        Quality(int rays, int distance, int intervalTicks, int sourceChecks) {
            this.rays = rays;
            this.distance = distance;
            this.intervalTicks = intervalTicks;
            this.sourceChecks = sourceChecks;
        }
    }

    public ReverbSettings() {
        quality = Quality.BALANCED;
        environmentInfluence = 1.0f;
        materialInfluence = 1.0f;
        transitionSeconds = 0.6f;
        air = new Profile();
        water = new Profile();
        materials = new LinkedHashMap<>();
    }

    public Material material(MaterialGroup group) {
        if (materials == null) materials = new LinkedHashMap<>();
        MaterialGroup selectedGroup = group == null ? MaterialGroup.OTHER : group;
        Material material = materials.computeIfAbsent(selectedGroup.name(),
                ignored -> new Material(selectedGroup.reflection, selectedGroup.absorption));
        material.reflection = bounded(material.reflection, 0.0f, 1.0f, selectedGroup.reflection);
        material.absorption = bounded(material.absorption, 0.0f, 1.0f, selectedGroup.absorption);
        return material;
    }

    public float transitionSeconds() {
        return bounded(transitionSeconds, 0.05f, 3.0f, 0.6f);
    }

    public float materialInfluence() {
        return bounded(materialInfluence, 0.0f, 1.0f, 1.0f);
    }

    public Profile profile(boolean underwater) {
        if (air == null) air = new Profile();
        if (water == null) water = new Profile();
        return underwater ? water : air;
    }

    public Quality quality() {
        return quality == null ? Quality.BALANCED : quality;
    }

    public static float bounded(float value, float min, float max, float fallback) {
        return Float.isFinite(value)
                ? Math.max(min, Math.min(max, value))
                : fallback;
    }

    public float environmentInfluence() {
        return bounded(environmentInfluence, 0.0f, 1.0f, 1.0f);
    }
}
