package com.soundify.config;

/** Thin facade reconstructed directly from original bytecode. */
public final class ConfigStore {
    private ConfigStore() { }
    public static void save() { SoundifyConfig.save(); }
    public static void load() { SoundifyConfig.load(); }
    public static void saveDebounced() { SoundifyConfig.saveDebounced(); }
    public static SoundifySettings settings() { return new SoundifySettings(SoundifyConfig.get()); }
    public static SoundifyConfig current() { return SoundifyConfig.get(); }
    public static void apply(SoundifyConfig config) { SoundifyConfig.apply(config); }
}
