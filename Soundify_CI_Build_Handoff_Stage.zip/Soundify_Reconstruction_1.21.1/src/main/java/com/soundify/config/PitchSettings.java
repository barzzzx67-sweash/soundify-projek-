package com.soundify.config;

/** Reconstructed from original bytecode. */
public final class PitchSettings {
    private PitchSettings() { }
    public static void set(String soundId, float min, float max) {
        ConfigStore.settings().setPitchRange(soundId, min, max);
        SoundifyConfig.saveDebounced();
    }
    public static SoundifyConfig.PitchRange get(String soundId) {
        return ConfigStore.settings().pitchRange(soundId);
    }
    public static float mapCodePitch(String soundId, float basePitch, float min, float max) {
        return ConfigStore.settings().mapCodePitch(soundId, basePitch, min, max);
    }
}
