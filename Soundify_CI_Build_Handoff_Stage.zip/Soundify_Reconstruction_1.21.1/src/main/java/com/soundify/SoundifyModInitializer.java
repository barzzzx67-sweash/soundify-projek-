package com.soundify;

import com.soundify.sound.catalog.CustomSounds;
import com.soundify.SoundifyReborn;
import net.fabricmc.api.ModInitializer;

/** Registers Soundify's custom SoundEvent instances before the client sound manager reloads. */
public final class SoundifyModInitializer implements ModInitializer {
    @Override
    public void onInitialize() {
        CustomSounds.initialize();
        SoundifyReborn.LOGGER.info("Registered {} Soundify catalog events ({} custom, {} vanilla overrides)",
                CustomSounds.totalCatalogSize(),
                CustomSounds.customCatalogSize(),
                CustomSounds.vanillaCatalogSize());
    }
}
