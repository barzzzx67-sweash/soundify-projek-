package com.soundify.ui.config;

import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

/** Placeholder screen to restore source completeness; full settings UI is not reconstructed yet. */
public final class ConfigScreens {
    private ConfigScreens() {}
    private static final class SoundifyPlaceholderScreen extends Screen {
        SoundifyPlaceholderScreen() { super(Text.literal("Soundify configuration (reconstruction placeholder)")); }
    }
    public static Screen create(Screen parent) { return new SoundifyPlaceholderScreen(); }
    public static boolean isConfigScreen(Screen screen) { return screen instanceof SoundifyPlaceholderScreen; }
}
