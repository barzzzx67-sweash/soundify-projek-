package com.soundify.sound.replacement;

import com.google.gson.*;
import net.minecraft.resource.Resource;
import net.minecraft.resource.ResourceManager;
import net.minecraft.util.Identifier;

import java.util.*;

/** Minecraft 1.21.1 adapter: indexes sound event definition JSON and referenced sound paths. */
public final class MinecraftResourceManagerAdapter {
    private MinecraftResourceManagerAdapter() {}

    public static SoundResourceIndex.Snapshot rebuild(ResourceManager manager) {
        Map<String, SoundResourceIndex.SoundEntry> entries = new LinkedHashMap<>();
        for (Map.Entry<Identifier, Resource> resource : manager.findResources("sounds", id -> id.getPath().endsWith(".json")).entrySet()) {
            Identifier definition = resource.getKey();
            String path = definition.getPath();
            if (!path.startsWith("sounds/") || !path.endsWith(".json")) continue;
            String eventPath = path.substring("sounds/".length(), path.length() - ".json".length());
            String eventId = definition.getNamespace() + ':' + eventPath;
            List<String> files = new ArrayList<>();
            try (var reader = resource.getValue().getReader()) {
                JsonElement root = JsonParser.parseReader(reader);
                if (!root.isJsonObject()) continue;
                JsonElement sounds = root.getAsJsonObject().get("sounds");
                if (sounds == null || !sounds.isJsonArray()) continue;
                for (JsonElement element : sounds.getAsJsonArray()) {
                    // Vanilla sound definitions accept either a string shorthand or an object.
                    JsonElement nameElement;
                    if (element.isJsonPrimitive() && element.getAsJsonPrimitive().isString()) {
                        nameElement = element;
                    } else if (element.isJsonObject()) {
                        nameElement = element.getAsJsonObject().get("name");
                    } else {
                        continue;
                    }
                    if (nameElement == null || !nameElement.isJsonPrimitive() || !nameElement.getAsJsonPrimitive().isString()) continue;
                    String name = nameElement.getAsString();
                    if (name.isBlank()) continue;
                    Identifier soundId = Identifier.tryParse(name);
                    if (soundId == null) continue;
                    // Sound references are logical IDs; the corresponding resource path is under sounds/.
                    String filePath = soundId.getPath().startsWith("sounds/")
                        ? soundId.getPath() : "sounds/" + soundId.getPath();
                    if (!filePath.endsWith(".ogg")) filePath += ".ogg";
                    files.add(soundId.getNamespace() + ':' + filePath);
                }
            } catch (Exception ignored) {
                // A malformed definition does not prevent indexing the remaining packs.
            }
            entries.put(eventId, new SoundResourceIndex.SoundEntry(eventId, files, true));
        }
        return SoundResourceIndex.publish(entries.values());
    }
}
