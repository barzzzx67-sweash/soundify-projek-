package com.soundify.sound.replacement;

import java.util.List;
import java.util.Objects;

/** Adapter-independent replacement selection. Resource existence is supplied by the MC adapter. */
public final class ReplacementResourceResolver {
    private ReplacementResourceResolver() {}

    @FunctionalInterface public interface ResourceProbe { boolean exists(String soundId); }

    /** Returns the first configured candidate that the resource probe confirms, else null. */
    public static String resolve(String originalId, ResourceProbe probe) {
        Objects.requireNonNull(probe, "probe");
        List<String> candidates = DynamicReplacementResolver.candidates(originalId);
        for (String candidate : candidates) {
            try { if (probe.exists(candidate)) return candidate; }
            catch (RuntimeException ignored) { /* a bad resource probe should not crash audio */ }
        }
        return null;
    }

    /** Safe replacement policy: never redirect to the original ID itself. */
    public static String resolveDistinct(String originalId, ResourceProbe probe) {
        String normalizedOriginal = DynamicReplacementResolver.normalize(originalId);
        for (String candidate : DynamicReplacementResolver.candidates(originalId)) {
            if (candidate.equals(normalizedOriginal)) continue;
            try { if (probe.exists(candidate)) return candidate; }
            catch (RuntimeException ignored) { }
        }
        return null;
    }
}
