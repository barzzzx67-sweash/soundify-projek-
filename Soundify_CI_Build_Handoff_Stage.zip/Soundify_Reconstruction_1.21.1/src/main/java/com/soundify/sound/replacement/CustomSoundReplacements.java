package com.soundify.sound.replacement;

/** Compatibility facade for invalidating the replacement resolver cache. */
public final class CustomSoundReplacements {
    private CustomSoundReplacements() {}
    public static void invalidateReplacementCache() { DynamicReplacementResolver.invalidate(); }
}
