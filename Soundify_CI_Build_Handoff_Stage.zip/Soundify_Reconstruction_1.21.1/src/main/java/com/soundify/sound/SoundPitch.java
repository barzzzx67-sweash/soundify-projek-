package com.soundify.sound;

import com.soundify.config.SoundifyCodePitchDefaults;
import com.soundify.config.SoundifyConfig;
import net.minecraft.util.math.random.Random;

import java.util.concurrent.ThreadLocalRandom;

/** Random pitch range helper reconstructed from the original SoundPitch class. */
public final class SoundPitch {
    private final float min;
    private final float max;

    public SoundPitch(float min, float max) {
        if (!Float.isFinite(min) || !Float.isFinite(max) || min <= 0.0f || max < min)
            throw new IllegalArgumentException("Invalid pitch range: " + min + ".." + max);
        this.min = min;
        this.max = max;
    }

    public SoundPitch(String soundId) {
        SoundifyConfig.PitchRange range = SoundifyCodePitchDefaults.randomRange(soundId);
        if (range == null) throw new IllegalArgumentException("No randomized code pitch registered for " + soundId);
        this.min = range.min;
        this.max = range.max;
    }

    public float next() { return min + ThreadLocalRandom.current().nextFloat() * (max - min); }
    public float next(java.util.Random random) { return min + random.nextFloat() * (max - min); }
    public float next(Random random) { return min + random.nextFloat() * (max - min); }
    public PlaybackPitch at(float value) { return PlaybackPitch.inRange(value, min, max); }
    public PlaybackPitch sample() { return at(next()); }
    public PlaybackPitch sample(java.util.Random random) { return at(next(random)); }
    public PlaybackPitch sample(Random random) { return at(next(random)); }
    public float min() { return min; }
    public float max() { return max; }
}
