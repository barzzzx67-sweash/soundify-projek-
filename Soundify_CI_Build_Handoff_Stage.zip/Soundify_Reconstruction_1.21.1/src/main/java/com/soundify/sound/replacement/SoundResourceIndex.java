package com.soundify.sound.replacement;

import java.util.*;
import java.util.concurrent.atomic.AtomicReference;

/** Immutable, reload-swappable index of sound event IDs and their sound-file references.
 * Minecraft ResourceManager adapters should populate this index after resource discovery.
 */
public final class SoundResourceIndex {
    private SoundResourceIndex() {}
    public record SoundEntry(String eventId, List<String> soundFiles, boolean hasDefinition) {
        public SoundEntry { eventId = DynamicReplacementResolver.normalize(eventId); soundFiles = List.copyOf(soundFiles == null ? List.of() : soundFiles); }
    }
    public record Snapshot(long generation, Map<String, SoundEntry> entries) {
        public Snapshot { entries = Collections.unmodifiableMap(new LinkedHashMap<>(entries)); }
        public boolean contains(String id) { return entries.containsKey(DynamicReplacementResolver.normalize(id)); }
        public SoundEntry get(String id) { return entries.get(DynamicReplacementResolver.normalize(id)); }
    }
    private static final AtomicReference<Snapshot> CURRENT = new AtomicReference<>(new Snapshot(0, Map.of()));
    public static Snapshot snapshot() { return CURRENT.get(); }
    /** Replace the entire index atomically after a reload; duplicates keep the last supplied definition. */
    public static Snapshot publish(Collection<SoundEntry> entries) {
        Map<String, SoundEntry> map = new LinkedHashMap<>();
        if (entries != null) for (SoundEntry e : entries) if (e != null && !e.eventId().isEmpty()) map.put(e.eventId(), e);
        Snapshot previous = CURRENT.get();
        Snapshot next = new Snapshot(previous.generation() + 1, map);
        CURRENT.set(next); DynamicReplacementResolver.invalidate(); return next;
    }
    public static void clear() { publish(List.of()); }
}
