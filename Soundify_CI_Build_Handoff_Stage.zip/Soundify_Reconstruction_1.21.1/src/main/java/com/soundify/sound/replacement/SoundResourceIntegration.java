package com.soundify.sound.replacement;

import java.util.List;

/** Bridges replacement policy to the currently published resource index. */
public final class SoundResourceIntegration {
    private SoundResourceIntegration() {}
    public static String resolve(String originalId) {
        SoundResourceIndex.Snapshot snapshot = SoundResourceIndex.snapshot();
        return ReplacementResourceResolver.resolveDistinct(originalId, snapshot::contains);
    }
    public static List<String> filesFor(String eventId) {
        SoundResourceIndex.SoundEntry entry = SoundResourceIndex.snapshot().get(eventId);
        return entry == null ? List.of() : entry.soundFiles();
    }
    public static boolean isAvailable(String eventId) { return SoundResourceIndex.snapshot().contains(eventId); }
}
