package com.soundify.sound;

import com.soundify.sound.catalog.CustomSounds;
import com.soundify.sound.catalog.CustomSounds.SoundEntry;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.client.sound.SoundInstance;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.World;

/**
 * Client-side playback facade reconstructed from Soundify's original
 * SoundPlayback API. Uses Yarn names for Minecraft 1.21.1.
 */
public final class SoundPlayback {
    private SoundPlayback() { }

    public static boolean playInstance(SoundInstance instance) {
        return SoundManagerBridge.play(instance);
    }

    public static boolean stopInstance(SoundInstance instance) {
        return SoundManagerBridge.stop(instance);
    }

    public static boolean playUi(String soundId, float volume, float pitch) {
        SoundEntry entry = CustomSounds.entry(soundId);
        return entry != null && playUi(entry.event(), volume, PlaybackPitch.runtime(pitch));
    }

    public static boolean playUi(SoundEvent event, float volume, float pitch) {
        return playUi(event, volume, PlaybackPitch.runtime(pitch));
    }

    public static boolean playUi(SoundEvent event, float volume, PlaybackPitch pitch) {
        if (event == null || pitch == null || !validVolume(volume)) return false;
        String id = soundId(event);
        float resolved = pitch.resolve(id);
        return playInstance(PositionedSoundInstance.master(event, resolved, volume));
    }

    public static boolean playOnPlayer(PlayerEntity player, SoundEvent event, float volume, float pitch) {
        if (player == null || event == null || !validVolume(volume)) return false;
        return playLocalConfigured(player.getWorld(), player.getX(), player.getY(), player.getZ(), event,
                SoundCategory.PLAYERS, volume, PlaybackPitch.runtime(pitch), false);
    }

    public static boolean playOnEntity(Entity entity, SoundEvent event, SoundCategory category,
                                       float volume, PlaybackPitch pitch) {
        if (entity == null || event == null || pitch == null || !validVolume(volume)) return false;
        return playLocalConfigured(entity.getWorld(), entity.getX(), entity.getY(), entity.getZ(), event,
                category, volume, pitch, false);
    }

    public static boolean playFixedOnPlayerConfigured(PlayerEntity player, String soundId) {
        SoundEntry entry = CustomSounds.entry(soundId);
        if (player == null || entry == null) return false;
        return playOnEntity(player, entry.event(), category(entry), entry.defaultMinVolume(),
                PlaybackPitch.runtime(1.0f));
    }

    public static boolean playFixedOnEntityConfigured(Entity entity, SoundEvent event, PlaybackPitch pitch) {
        if (entity == null || event == null || pitch == null) return false;
        SoundEntry entry = CustomSounds.entry(soundId(event));
        SoundCategory category = entry == null ? SoundCategory.PLAYERS : category(entry);
        float volume = entry == null ? 1.0f : entry.defaultMinVolume();
        return playOnEntity(entity, event, category, volume, pitch);
    }

    public static boolean playLocalConfigured(World world, double x, double y, double z,
                                               SoundEvent event, SoundCategory category,
                                               float volume, PlaybackPitch pitch,
                                               boolean directional) {
        if (world == null || event == null || pitch == null || !validVolume(volume)) return false;
        String id = soundId(event);
        float resolvedPitch = pitch.resolve(id);
        // In 1.21.1 the positional sound instance handles attenuation and
        // spatialization; the directional flag is retained for future parity
        // with Soundify's directional-delay mixins.
        SoundInstance instance = new PositionedSoundInstance(event, category, volume,
                resolvedPitch, Random.create(), x, y, z);
        return playInstance(instance);
    }

    public static boolean playLocalConfigured(World world, double x, double y, double z,
                                               String soundId, SoundCategory category,
                                               float volume, boolean directional) {
        SoundEntry entry = CustomSounds.entry(soundId);
        return entry != null && playLocalConfigured(world, x, y, z, entry.event(), category,
                volume, PlaybackPitch.runtime(1.0f), directional);
    }

    public static boolean playAtPlayerConfigured(String soundId, SoundCategory category,
                                                 float volume, PlaybackPitch pitch) {
        MinecraftClient client = MinecraftClient.getInstance();
        PlayerEntity player = client == null ? null : client.player;
        SoundEntry entry = CustomSounds.entry(soundId);
        if (player == null || entry == null) return false;
        return playLocalConfigured(player.getWorld(), player.getX(), player.getY(), player.getZ(),
                entry.event(), category == null ? category(entry) : category, volume, pitch, false);
    }

    private static SoundCategory category(SoundEntry entry) {
        if (entry == null || entry.category() == null) return SoundCategory.PLAYERS;
        String key = entry.category().trim().toLowerCase(java.util.Locale.ROOT);
        return switch (key) {
            case "player", "players" -> SoundCategory.PLAYERS;
            case "block", "blocks" -> SoundCategory.BLOCKS;
            case "hostile" -> SoundCategory.HOSTILE;
            case "neutral" -> SoundCategory.NEUTRAL;
            case "ambient" -> SoundCategory.AMBIENT;
            case "weather" -> SoundCategory.WEATHER;
            case "music" -> SoundCategory.MUSIC;
            case "record", "records" -> SoundCategory.RECORDS;
            case "voice" -> SoundCategory.VOICE;
            case "ui" -> SoundCategory.MASTER;
            default -> SoundCategory.PLAYERS;
        };
    }

    /** Rejects invalid volume before it reaches the sound engine. */
    private static boolean validVolume(float volume) {
        return Float.isFinite(volume) && volume >= 0.0f;
    }

    private static String soundId(SoundEvent event) {
        for (SoundEntry entry : CustomSounds.entries()) {
            if (entry.event() == event || entry.event().equals(event)) return entry.id();
        }
        return "";
    }

}
