package com.soundify.sound.replacement;

import net.minecraft.util.Identifier;

import java.util.Collection;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.concurrent.atomic.AtomicReference;

/** Immutable view of event soundsets that Minecraft actually loaded in the latest sound reload. */
public final class LoadedSoundSetIndex {
    private LoadedSoundSetIndex() {}

    public record Snapshot(long generation, Set<String> eventIds) {
        public Snapshot {
            eventIds = Set.copyOf(eventIds == null ? Set.of() : eventIds);
        }
        public boolean contains(String id) {
            return eventIds.contains(DynamicReplacementResolver.normalize(id));
        }
    }

    private static final AtomicReference<Snapshot> CURRENT =
        new AtomicReference<>(new Snapshot(0, Set.of()));

    public static Snapshot snapshot() { return CURRENT.get(); }

    public static Snapshot publish(Collection<Identifier> identifiers) {
        Set<String> ids = new LinkedHashSet<>();
        if (identifiers != null) {
            for (Identifier id : identifiers) {
                if (id != null) ids.add(DynamicReplacementResolver.normalize(id.toString()));
            }
        }
        Snapshot previous = CURRENT.get();
        Snapshot next = new Snapshot(previous.generation() + 1, ids);
        CURRENT.set(next);
        DynamicReplacementResolver.invalidate();
        return next;
    }

    public static void clear() { publish(Set.of()); }
}
