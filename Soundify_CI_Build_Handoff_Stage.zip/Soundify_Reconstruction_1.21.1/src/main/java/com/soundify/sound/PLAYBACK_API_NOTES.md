# Playback API notes

The original Soundify bytecode exposes playback entry points for UI, local positions, entities/players, configured pitch, direct instance play/stop, and delayed playback.

This porting stage currently implements the immediate-play subset using Yarn-style names. Delayed playback is deliberately not faked with a timer; it will be added with the appropriate client tick scheduling after confirming the 1.21.1 runtime API and original timing semantics.
