package com.soundify.sound;

/** Pure directional placement policy, separated from version-specific Minecraft mixin fields. */
public final class DirectionalSoundPolicy {
    public enum Attenuation { NONE, LINEAR }
    public record Position(double x, double y, double z) {}
    public record Result(boolean relative, Position position, Attenuation attenuation) {}

    private DirectionalSoundPolicy() {}

    /**
     * Non-directional custom sounds are camera-relative, centered and unattenuated.
     * Directional sounds become world-positioned and linearly attenuated. If the sound
     * started camera-relative, its current camera position is used as the world origin.
     */
    public static Result resolve(boolean customSound, boolean directionEnabled,
                                 boolean currentlyRelative, Position currentPosition,
                                 Position cameraPosition) {
        Position zero = new Position(0.0, 0.0, 0.0);
        if (!customSound) return new Result(currentlyRelative, currentPosition, Attenuation.LINEAR);
        if (!directionEnabled) return new Result(true, zero, Attenuation.NONE);
        Position worldPosition = currentlyRelative
                ? (cameraPosition == null ? zero : cameraPosition)
                : (currentPosition == null ? zero : currentPosition);
        return new Result(false, worldPosition, Attenuation.LINEAR);
    }
}
