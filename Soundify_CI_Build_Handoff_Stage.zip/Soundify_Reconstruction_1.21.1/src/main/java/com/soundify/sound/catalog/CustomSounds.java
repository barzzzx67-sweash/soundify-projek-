package com.soundify.sound.catalog;

import net.minecraft.client.sound.Sound;
import net.minecraft.registry.Registries;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.Identifier;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Partial source reconstruction of the original CustomSounds catalog.
 * The parsing and lookup behavior follows the original class disassembly.
 * Generated catalog row data is intentionally kept separate and is not
 * fabricated here; feed the recovered rows through registerRows().
 */
public final class CustomSounds {
    private static final Map<String, SoundEntry> CUSTOM_SOUNDS = new LinkedHashMap<>();
    private static boolean initialized;
    private static int customCatalogRows;
    private static int vanillaCatalogRows;

    private CustomSounds() {}

    public record SoundVariant(String name, float volume, float pitch, int weight,
                               boolean stream, boolean preload, int attenuationDistance,
                               Sound.Type type) {}

    public record SoundEntry(String id, String soundPath, String category, String group,
                             String name, float defaultMinPitch, float defaultMaxPitch,
                             float defaultMinVolume, float defaultMaxVolume, SoundEvent event,
                             List<SoundVariant> sounds, boolean direction, boolean underwater) {
        public SoundEntry {
            name = name == null ? "" : name.trim();
            sounds = List.copyOf(sounds);
        }

        public String defaultVariantNamespace() {
            return vanilla() ? "minecraft" : SoundEventRegistry.MOD_ID;
        }

        public boolean vanilla() {
            return id != null && id.startsWith("minecraft:");
        }
    }

    public static Collection<String> registeredIds() {
        return Collections.unmodifiableSet(CUSTOM_SOUNDS.keySet());
    }

    public static boolean contains(String id) {
        return CUSTOM_SOUNDS.containsKey(normalizeId(id));
    }

    public static SoundEntry entry(String id) {
        return CUSTOM_SOUNDS.get(normalizeId(id));
    }

    public static SoundEvent get(String id) {
        SoundEvent event = byId(id);
        if (event == null) throw new IllegalArgumentException("Unknown Soundify sound: " + id);
        return event;
    }

    public static Collection<SoundEntry> entries() {
        return Collections.unmodifiableCollection(CUSTOM_SOUNDS.values());
    }

    public static boolean isNew(String id) {
        SoundEntry entry = entry(id);
        return entry != null && !entry.vanilla();
    }

    public static boolean isEdited(String id) {
        SoundEntry entry = entry(id);
        return entry != null && entry.vanilla();
    }

    public static float defaultMinPitch(String id) {
        SoundEntry entry = entry(id);
        return entry == null ? 1.0f : entry.defaultMinPitch();
    }

    public static float defaultMaxPitch(String id) {
        SoundEntry entry = entry(id);
        return entry == null ? 1.0f : entry.defaultMaxPitch();
    }

    /** Called by the generated catalog bootstrap once its original rows are restored. */
    public static synchronized void initialize() {
        if (initialized) return;

        // Register Soundify entries first, then vanilla overrides. These tables
        // contain distinct IDs, so the combined catalog should contain 395 rows.
        registerRows(GeneratedSoundCatalog.ENTRIES, GeneratedSoundCatalog.SOUNDS);
        customCatalogRows = GeneratedSoundCatalog.ENTRIES.length;

        registerRows(GeneratedVanillaSoundCatalog.ENTRIES,
                     GeneratedVanillaSoundCatalog.SOUNDS);
        vanillaCatalogRows = GeneratedVanillaSoundCatalog.ENTRIES.length;

        initialized = true;
    }

    public static boolean isInitialized() { return initialized; }
    public static int customCatalogSize() { return customCatalogRows; }
    public static int vanillaCatalogSize() { return vanillaCatalogRows; }
    public static int totalCatalogSize() { return CUSTOM_SOUNDS.size(); }

    public static int registeredVariantCount() {
        int count = 0;
        for (SoundEntry entry : CUSTOM_SOUNDS.values()) count += entry.sounds().size();
        return count;
    }

    static void registerRows(String[][] rows, String[][][] variants) {
        for (int i = 0; i < rows.length; i++) {
            String[] row = rows[i];
            if (row == null || row.length < 4 || row[0] == null || row[0].isBlank()) continue;
            String[][] variantRows = variants != null && i < variants.length
                    ? variants[i] : new String[0][];
            Identifier identifier = parseEventIdentifier(row[0]);
            SoundEvent event = row[0].startsWith("minecraft:")
                    ? vanillaEvent(identifier) : SoundEventRegistry.register(identifier.getPath());
            CUSTOM_SOUNDS.put(row[0], new SoundEntry(
                    row[0], row[1], row[2], row[3], value(row, 9, ""),
                    parsePitch(row, 4), parsePitch(row, 5), parseFloat(row, 6, 1.0f),
                    parseFloat(row, 7, 1.0f), event, parseSounds(variantRows),
                    parseBoolean(row, 10, true), parseBoolean(row, 11, true)));
        }
    }

    private static List<SoundVariant> parseSounds(String[][] rows) {
        List<SoundVariant> result = new ArrayList<>();
        if (rows == null) return result;
        for (String[] row : rows) {
            if (row == null || row.length < 1 || row[0] == null || row[0].isBlank()) continue;
            result.add(new SoundVariant(row[0], parseFloat(row, 1, 1.0f),
                    parseFloat(row, 2, 1.0f), parseInt(row, 3, 1),
                    parseBoolean(row, 4, false), parseBoolean(row, 5, false),
                    parseInt(row, 6, 16), parseSoundType(row, 7)));
        }
        return List.copyOf(result);
    }

    private static Sound.Type parseSoundType(String[] row, int index) {
        String value = value(row, index, "");
        if (value.isBlank()) return Sound.Type.FILE;
        try { return Sound.Type.valueOf(value.trim().toUpperCase()); }
        catch (IllegalArgumentException ignored) { return Sound.Type.FILE; }
    }

    private static Identifier parseEventIdentifier(String value) {
        int colon = value.indexOf(':');
        if (colon < 0) return SoundEventRegistry.id(value);
        return Identifier.of(value.substring(0, colon), value.substring(colon + 1));
    }

    private static SoundEvent vanillaEvent(Identifier id) {
        SoundEvent event = Registries.SOUND_EVENT.get(id);
        return event != null ? event : SoundEvent.of(id);
    }

    private static SoundEvent byId(String id) {
        SoundEntry entry = entry(id);
        if (entry != null) return entry.event();
        Identifier identifier = parseEventIdentifier(id);
        return Registries.SOUND_EVENT.get(identifier);
    }

    private static String normalizeId(String id) {
        if (id == null) return "";
        String prefix = SoundEventRegistry.MOD_ID + ":";
        return id.startsWith(prefix) ? id.substring(prefix.length()) : id;
    }

    private static String value(String[] values, int index, String fallback) {
        return values != null && index < values.length && values[index] != null
                ? values[index] : fallback;
    }

    private static float parsePitch(String[] row, int index) { return parseFloat(row, index, 1.0f); }
    private static float parseFloat(String[] row, int index, float fallback) {
        String value = value(row, index, "");
        if (value.isBlank()) return fallback;
        try { return Float.parseFloat(value); }
        catch (NumberFormatException ignored) { return fallback; }
    }
    private static int parseInt(String[] row, int index, int fallback) {
        String value = value(row, index, "");
        if (value.isBlank()) return fallback;
        try { return Integer.parseInt(value); }
        catch (NumberFormatException ignored) { return fallback; }
    }
    private static boolean parseBoolean(String[] row, int index, boolean fallback) {
        String value = value(row, index, "");
        return value.isBlank() ? fallback : Boolean.parseBoolean(value);
    }
}
