package com.soundify.sound;

/** Marker contract used by the sound-engine hook to apply custom directional settings. */
public interface DirectionalSoundInstance {
    void soundify$applyDirection();
}
