package com.soundify.sound;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.sound.SoundInstance;
import net.minecraft.client.sound.SoundManager;

/** Narrow client-side bridge around Minecraft's SoundManager. */
public final class SoundManagerBridge {
    private SoundManagerBridge() { }

    public static SoundManager manager() {
        MinecraftClient client = MinecraftClient.getInstance();
        return client == null ? null : client.getSoundManager();
    }

    public static boolean play(SoundInstance instance) {
        if (instance == null) return false;
        SoundManager manager = manager();
        if (manager == null) return false;
        manager.play(instance);
        return true;
    }

    public static boolean stop(SoundInstance instance) {
        if (instance == null) return false;
        SoundManager manager = manager();
        if (manager == null) return false;
        manager.stop(instance);
        return true;
    }
}
