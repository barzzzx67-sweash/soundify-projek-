package com.soundify.sound.replacement;

import com.soundify.config.ConfigStore;
import com.soundify.sound.catalog.CustomSounds;
import java.util.*;

/** Dynamic event redirection reconstructed from the original replacement Mixin flow. */
public final class DynamicReplacementResolver {
    private DynamicReplacementResolver() {}
    private static volatile int observedConfigHash;
    private static final Map<String,List<String>> CACHE = new LinkedHashMap<>();

    public static List<String> candidates(String originalId) {
        String original = normalize(originalId);
        if (original.isEmpty()) return List.of();
        refreshIfNeeded();
        synchronized (CACHE) {
            List<String> cached = CACHE.get(original);
            if (cached != null) return cached;
        }
        List<String> configured = ConfigStore.settings().replacementSoundIds(original);
        List<String> result = normalizeCandidates(configured);
        if (result.isEmpty()) {
            String single = ConfigStore.settings().replacementSoundId(original);
            result = normalizeCandidates(single == null ? List.of() : List.of(single));
        }
        if (result.isEmpty() && CustomSounds.contains(original)) result = List.of(original);
        synchronized (CACHE) { CACHE.put(original, result); }
        return result;
    }

    /** First candidate is the priority target; callers can try subsequent candidates if absent. */
    public static String selectedId(String originalId) {
        List<String> candidates = candidates(originalId);
        return candidates.isEmpty() ? null : candidates.get(0);
    }

    public static boolean mayMatch(String originalId) { return !candidates(originalId).isEmpty(); }
    public static synchronized void invalidate() { synchronized (CACHE) { CACHE.clear(); } observedConfigHash = ConfigStore.settings().replacementHash(); }
    private static void refreshIfNeeded() {
        int hash = ConfigStore.settings().replacementHash();
        if (hash != observedConfigHash) { synchronized (CACHE) { CACHE.clear(); } observedConfigHash = hash; }
    }
    private static List<String> normalizeCandidates(Collection<String> input) {
        if (input == null || input.isEmpty()) return List.of();
        LinkedHashSet<String> ids = new LinkedHashSet<>();
        for (String s : input) { String n = normalize(s); if (!n.isEmpty()) ids.add(n); }
        return List.copyOf(ids);
    }
    public static String normalize(String id) {
        if (id == null) return "";
        String s=id.trim().toLowerCase(Locale.ROOT);
        if (s.isEmpty()) return "";
        return s.contains(":") ? s : "minecraft:"+s;
    }
}
