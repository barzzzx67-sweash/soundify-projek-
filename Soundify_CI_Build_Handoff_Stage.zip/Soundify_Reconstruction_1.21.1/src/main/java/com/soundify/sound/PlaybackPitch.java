package com.soundify.sound;

import com.soundify.config.SoundifyConfig;

/**
 * Reconstructed pitch policy used by SoundPlayback.
 * A runtime pitch is an absolute multiplier; a mapped pitch preserves the
 * original code's relative position inside a known min/max range.
 */
public final class PlaybackPitch {
    private final boolean mapped;
    private final float value;
    private final float min;
    private final float max;

    private PlaybackPitch(float value, float min, float max, boolean mapped) {
        this.value = finitePositive(value, "value");
        this.min = finitePositive(min, "min");
        this.max = finitePositive(max, "max");
        if (mapped && max < min) throw new IllegalArgumentException("max pitch must be >= min pitch");
        this.mapped = mapped;
    }

    public static PlaybackPitch runtime(float pitch) {
        return new PlaybackPitch(pitch, 1.0f, 1.0f, false);
    }

    public static PlaybackPitch inRange(float value, float min, float max) {
        if (max < min) throw new IllegalArgumentException("max pitch must be greater than or equal to min pitch");
        return new PlaybackPitch(value, min, max, true);
    }

    public float resolve(String soundId) {
        SoundifyConfig config = SoundifyConfig.get();
        String key = SoundifyConfig.storageKeyForInternalUse(soundId);
        return mapped
                ? config.mapCodePitchOverride(key, value, min, max)
                : config.applyPitchOverride(key, value);
    }

    public boolean isMapped() { return mapped; }
    public float value() { return value; }
    public float min() { return min; }
    public float max() { return max; }

    private static float finitePositive(float value, String name) {
        if (!Float.isFinite(value) || value <= 0.0f)
            throw new IllegalArgumentException(name + " must be finite and > 0");
        return value;
    }
}
