package com.soundify.sound.catalog;

import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.Identifier;

import java.util.Collection;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Java 21 / Minecraft 1.21.1 Yarn reconstruction of SoundEventRegistry.
 * Recovered behavior: namespaced Soundify IDs, reuse an existing event when
 * present, otherwise register a variable-range event and retain it by path.
 */
public final class SoundEventRegistry {
    public static final String MOD_ID = "soundify-reborn";
    private static final Map<String, SoundEvent> MOD_EVENTS = new LinkedHashMap<>();

    private SoundEventRegistry() {}

    public static Collection<String> ids() {
        return Collections.unmodifiableSet(MOD_EVENTS.keySet());
    }

    public static Identifier id(String path) {
        return Identifier.of(MOD_ID, path);
    }

    public static SoundEvent register(String path) {
        Identifier identifier = id(path);
        SoundEvent existing = Registries.SOUND_EVENT.getOrEmpty(identifier).orElse(null);
        if (existing != null) {
            MOD_EVENTS.put(path, existing);
            return existing;
        }

        // Must run during mod initialization, before registries are frozen.
        SoundEvent created = SoundEvent.of(identifier);
        SoundEvent registered = Registry.register(Registries.SOUND_EVENT, identifier, created);
        MOD_EVENTS.put(path, registered);
        return registered;
    }

    public static SoundEvent get(String path) {
        SoundEvent event = MOD_EVENTS.get(path);
        return event != null ? event : Registries.SOUND_EVENT.getOrEmpty(id(path)).orElse(null);
    }

    public static int registeredCount() { return MOD_EVENTS.size(); }
}
