package com.soundify.sound.catalog;

import java.util.HashSet;
import java.util.Set;

/** Lookup facade over the reconstructed vanilla override table. */
public final class VanillaSoundCatalog {
    private static final Set<String> IDS = build();
    private VanillaSoundCatalog() {}
    private static Set<String> build() {
        Set<String> ids = new HashSet<>();
        for (String[] row : GeneratedVanillaSoundCatalog.ENTRIES) if (row != null && row.length > 0) ids.add(row[0]);
        for (String[] row : GeneratedSoundCatalog.ENTRIES) if (row != null && row.length > 0 && row[0].startsWith("minecraft:")) ids.add(row[0]);
        return Set.copyOf(ids);
    }
    public static boolean contains(String id) { if (id == null) return false; return IDS.contains(id.startsWith("minecraft:") ? id : "minecraft:" + id); }
    public static Set<String> ids() { return IDS; }
}
