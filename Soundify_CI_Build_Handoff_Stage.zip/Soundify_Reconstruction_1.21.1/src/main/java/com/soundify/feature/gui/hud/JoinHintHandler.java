package com.soundify.feature.gui.hud;

/** Minimal compatibility surface for the reconstructed config entry point. */
public final class JoinHintHandler {
    private static volatile boolean configOpened;
    private JoinHintHandler() {}
    public static void markConfigOpened() { configOpened = true; }
    public static boolean wasConfigOpened() { return configOpened; }
    public static void reset() { configOpened = false; }
}
