package com.soundify.feature.combat;

import net.minecraft.entity.LivingEntity;

/** Small policy helper reconstructed from original bytecode. */
final class CombatSoundPolicy {
    private static final float MIN_DAMAGE = 0.01F;
    private CombatSoundPolicy() { }

    static boolean isDead(LivingEntity entity) {
        return entity == null || entity.getHealth() <= 0.0F || !entity.isAlive() || entity.isRemoved();
    }
    static boolean expired(long now, long then, long duration) {
        return now - then > duration;
    }
    static boolean hasMeaningfulDamage(float damage) { return damage > MIN_DAMAGE; }
}
