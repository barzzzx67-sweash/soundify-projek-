# Source reconstruction status

| Part | Evidence recovered | Reconstructed Java source | 1.21.1 compile status |
|---|---|---:|---|
| `SoundifyReborn` | fields + static initializer | Yes | Not tested |
| `SoundifyClient` | field declarations + all methods | Yes | Requires mapping/API port |
| `ConfigStore` | all methods + bytecode | Yes | Depends on remaining config classes |
| `SoundifySettings` | all fields/methods + delegate behavior | Yes | Depends on `SoundifyConfig` source |
| `AudioTrimSettings`, `PitchSettings`, `ReplacementSettings` | full method bodies | Yes | Depends on config source |
| `ConfigView` | both methods | Yes | Depends on 1.21.1 Screen/API mapping |
| `CombatSoundPolicy` | all method bodies | Yes | Depends on entity API mapping |
| Remaining Soundify classes | class signatures and JVM instruction dumps | No | Not ready |
| 108 declared Mixin classes | target and annotation inspection | No | Not ported |

`javap` is a bytecode disassembler, not a Java decompiler. The text dumps preserve executable instructions and descriptors so the source can be reconstructed systematically, but they are not equivalent to original `.java` files.
