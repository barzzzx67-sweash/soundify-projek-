@echo off
setlocal EnableDelayedExpansion
set "GRADLE_VERSION=8.12"
if not defined GRADLE_USER_HOME set "GRADLE_USER_HOME=%USERPROFILE%\.gradle"
set "GRADLE_DIR=%GRADLE_USER_HOME%\wrapper\dists\soundify-bootstrap\gradle-%GRADLE_VERSION%"
set "GRADLE_BIN=%GRADLE_DIR%\bin\gradle.bat"

where gradle >nul 2>nul
if not errorlevel 1 (
  set "GLOBAL_GRADLE_VERSION="
  for /f "tokens=2" %%V in ('gradle --version ^| findstr /B /C:"Gradle "') do set "GLOBAL_GRADLE_VERSION=%%V"
  if "!GLOBAL_GRADLE_VERSION!"=="%GRADLE_VERSION%" (
    gradle %*
    exit /b !errorlevel!
  )
)

if not exist "%GRADLE_BIN%" (
  if not exist "%GRADLE_USER_HOME%\wrapper\dists\soundify-bootstrap" mkdir "%GRADLE_USER_HOME%\wrapper\dists\soundify-bootstrap"
  set "ARCHIVE=%GRADLE_USER_HOME%\wrapper\dists\soundify-bootstrap\gradle-%GRADLE_VERSION%-bin.zip"
  powershell -NoProfile -ExecutionPolicy Bypass -Command "$ProgressPreference='SilentlyContinue'; Invoke-WebRequest -Uri 'https://services.gradle.org/distributions/gradle-%GRADLE_VERSION%-bin.zip' -OutFile $env:ARCHIVE; Expand-Archive -LiteralPath $env:ARCHIVE -DestinationPath (Split-Path $env:ARCHIVE) -Force"
  if errorlevel 1 exit /b 1
)

if not exist "%GRADLE_BIN%" (
  echo ERROR: Gradle bootstrap failed. Check network access and PowerShell.
  exit /b 1
)
call "%GRADLE_BIN%" %*
exit /b %errorlevel%
