# Sound Definition Repair — Minecraft Java 1.21.1

## Perubahan
- Memperbaiki referensi `axe_impact` agar hanya menunjuk `axe_impact1..3` yang benar-benar ada.
- Memperbaiki `default_select` agar menunjuk `default_select1..3`.
- Memperbaiki `tab_click` agar menunjuk aset tunggal `tab_click.ogg`.
- Mengganti nama yang tidak ada pada `concrete_walk` dan `concrete_run` dengan enam aset konkret yang tersedia (`concrete1..6`). Kedua event memakai kumpulan aset yang sama karena arsip sumber tidak menyediakan dua set terpisah walk/run; ini merupakan fallback berbasis aset, bukan klaim bahwa rekaman berbeda.
- Memperbaiki `leaves_through` agar menunjuk empat aset yang tersedia.
- Tidak mengubah 22 referensi namespace `minecraft:`. Itu adalah referensi sound ID eksternal yang harus diresolusikan oleh vanilla Minecraft 1.21.1, bukan file yang harus berada di namespace mod.

## Hasil validasi
- 283 definisi event JSON berhasil diparse.
- 722 referensi suara total setelah membuang referensi custom yang tidak memiliki file.
- 700 referensi `soundify-reborn:` semuanya memiliki file audio.
- 22 referensi `minecraft:` ditandai `VANILLA_EXTERNAL` dan belum diverifikasi terhadap resource pack vanilla 1.21.1.
- Tidak ada event tanpa daftar `sounds`.
- 978 aset audio tetap dipertahankan; file yang belum direferensikan dicatat dalam `SOUND_ASSET_UNREFERENCED.csv`.
- Signature OGG/WAV diperiksa ulang.

## Batasan
Validasi ini memastikan struktur JSON dan keberadaan file pada resource proyek. Ini belum menguji decoding audio, kesesuaian semantik tiap rekaman, atau playback dalam game. Untuk `concrete_walk` dan `concrete_run`, aset sumber tidak memisahkan variasi berjalan dan berlari sehingga keduanya menggunakan enam rekaman konkret yang tersedia.
