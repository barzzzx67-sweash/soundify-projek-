# Stage: SoundManager Dynamic Replacement adapter

This stage adds `ReplacementResourceResolver`, a resource-probe adapter seam that selects the first configured replacement whose sound resource is available. It preserves configured candidate ordering and treats probe failures as misses.

## Why this is not yet a Mixin

The source archive does not include a verified Yarn 1.21.1 mapped signature/bytecode for the exact `SoundManager` preparation/reload target used by Soundify 26.3. Injecting into guessed method names or argument types risks a client startup crash. This stage intentionally does not add an unverified Mixin or claim runtime redirection.

Next integration target: use the verified 1.21.1 `SoundManager` preparation/reload method and its sound-definition map/resource lookup, then map original sound identifiers to resolved candidate identifiers while retaining vanilla fallback behavior.
